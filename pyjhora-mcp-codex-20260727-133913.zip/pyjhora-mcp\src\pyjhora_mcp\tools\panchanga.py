"""Panchanga-related MCP tools.

Wraps: jhora.panchanga.drik
"""

from __future__ import annotations

from typing import Any

from fastmcp import FastMCP

from pyjhora_mcp.models.schemas import (
    BirthDataInput,
    DateTimeInput,
    FestivalsResult,
    MuhurthaResult,
    PanchangaResult,
    PlaceInput,
    PlanetPositionsResult,
    RahuKalaResult,
    SunriseSunsetResult,
)
from pyjhora_mcp.utils.converters import (
    error_payload,
    format_time,
    karana_id_to_name,
    masa_id_to_name,
    nakshatra_id_to_name,
    planet_id_to_name,
    rasi_id_to_name,
    samvatsara_id_to_name,
    set_ayanamsa,
    tithi_id_to_name,
    to_julian_day,
    to_place,
    vaara_id_to_name,
    yoga_id_to_name,
)

mcp = FastMCP(name="Panchanga Tools")


def _clock_time(value: Any) -> str:
    """Return a PyJHora time result as HH:MM:SS."""
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple)):
        if len(value) > 1 and isinstance(value[1], str):
            return value[1]
        if value:
            return _clock_time(value[0])
        return "N/A"
    return format_time(value)


def _period(value: Any) -> dict[str, str]:
    """Return a start/end dict from PyJHora period output."""
    if isinstance(value, (list, tuple)) and len(value) >= 2:
        if isinstance(value[0], (list, tuple)):
            return _period(value[0])
        return {"start": _clock_time(value[0]), "end": _clock_time(value[1])}
    return {"start": _clock_time(value), "end": "N/A"}


def _period_list(value: Any) -> list[dict[str, str]]:
    """Return one or more start/end periods from PyJHora output."""
    if isinstance(value, (list, tuple)):
        if len(value) == 2 and not isinstance(value[0], (list, tuple)):
            return [_period(value)]
        if len(value) % 2 == 0 and all(not isinstance(v, (list, tuple)) for v in value):
            return [_period(value[i : i + 2]) for i in range(0, len(value), 2)]
        return [_period(v) for v in value]
    return [_period(value)]


def _date_input_to_drik_date(date_time: DateTimeInput) -> Any:
    from jhora.panchanga.drik import Date

    return Date(date_time.year, date_time.month, date_time.day)


# ---------------------------------------------------------------------------
# get_panchanga
# ---------------------------------------------------------------------------


@mcp.tool
def get_panchanga(birth_data: BirthDataInput) -> PanchangaResult:
    """Calculate the Panchanga (Hindu almanac) for a given date, time and place.

    Returns the five limbs of the Panchanga:
    - **Tithi** (lunar day) with index, name, paksha, and end time
    - **Nakshatra** (lunar mansion) with index, name, pada, and end time
    - **Yoga** with index, name, and end time
    - **Karana** with index and name
    - **Vaara** (day of week)

    Also returns the Masa (lunar month), Samvatsara (Vedic year), and Ritu (season).

    Args:
        birth_data: Location, date, and time for calculation.

    Returns:
        Dictionary with panchanga details.
    """
    from jhora.panchanga import drik

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)
    panchanga_date = _date_input_to_drik_date(birth_data.date_time)

    result: dict[str, Any] = {}
    lunar_month_index: int | None = None

    # --- Tithi ---
    try:
        tithi_data = drik.tithi(jd, place)
        if tithi_data:
            tid, tend = int(tithi_data[0]), tithi_data[2]
            paksha = "Shukla" if tid <= 15 else "Krishna"
            result["tithi"] = {
                "index": tid,
                "name": tithi_id_to_name(tid),
                "paksha": paksha,
                "end_time": format_time(tend),
            }
    except Exception as e:
        result["tithi"] = {"error": error_payload(e)}

    # --- Nakshatra ---
    try:
        nak_data = drik.nakshatra(jd, place)
        if nak_data:
            nid, nend = int(nak_data[0]), nak_data[2]
            pada = int(nak_data[1]) if len(nak_data) > 1 else None
            result["nakshatra"] = {
                "index": nid,
                "name": nakshatra_id_to_name(nid),
                "end_time": format_time(nend),
            }
            if pada is not None:
                result["nakshatra"]["pada"] = pada
    except Exception as e:
        result["nakshatra"] = {"error": error_payload(e)}

    # --- Yoga ---
    try:
        yoga_data = drik.yogam(jd, place)
        if yoga_data:
            yid, yend = int(yoga_data[0]), yoga_data[2]
            result["yoga"] = {
                "index": yid,
                "name": yoga_id_to_name(yid),
                "end_time": format_time(yend),
            }
    except Exception as e:
        result["yoga"] = {"error": error_payload(e)}

    # --- Karana ---
    try:
        kar_data = drik.karana(jd, place)
        if kar_data:
            kid = int(kar_data[0])
            result["karana"] = {
                "index": kid,
                "name": karana_id_to_name(kid),
            }
    except Exception as e:
        result["karana"] = {"error": error_payload(e)}

    # --- Vaara ---
    try:
        vid = drik.vaara(jd)
        result["vaara"] = vaara_id_to_name(vid)
    except Exception as e:
        result["vaara"] = {"error": error_payload(e)}

    # --- Masa ---
    try:
        masa_data = drik.lunar_month(jd, place)
        if masa_data is not None:
            mid = masa_data[0] if isinstance(masa_data, (list, tuple)) else masa_data
            lunar_month_index = int(mid)
            result["masa"] = masa_id_to_name(int(mid))
    except Exception as e:
        result["masa"] = {"error": error_payload(e)}

    # --- Samvatsara ---
    try:
        sv_data = drik.samvatsara(panchanga_date, place)
        if sv_data is not None:
            sid = sv_data[0] if isinstance(sv_data, (list, tuple)) else sv_data
            result["samvatsara"] = samvatsara_id_to_name(int(sid))
    except Exception as e:
        result["samvatsara"] = {"error": error_payload(e)}

    # --- Ritu ---
    try:
        if lunar_month_index is not None:
            result["ritu"] = drik.ritu(lunar_month_index)
    except Exception as e:
        result["ritu"] = {"error": error_payload(e)}

    return result


# ---------------------------------------------------------------------------
# get_sunrise_sunset
# ---------------------------------------------------------------------------


@mcp.tool
def get_sunrise_sunset(place: PlaceInput, date_time: DateTimeInput) -> SunriseSunsetResult:
    """Calculate sunrise, sunset, moonrise, and moonset times for a given date and place.

    All times are returned in local time (HH:MM:SS format).

    Args:
        place: Geographic location with coordinates and timezone.
        date_time: Date for which to calculate (time of day is ignored).

    Returns:
        Dictionary with sunrise, sunset, moonrise, moonset, and midday times.
    """
    from jhora.panchanga import drik

    jd = to_julian_day(date_time)
    p = to_place(place)

    result: dict[str, Any] = {}

    try:
        sr = drik.sunrise(jd, p)
        result["sunrise"] = _clock_time(sr) if sr else "N/A"
    except Exception as e:
        result["sunrise"] = {"error": error_payload(e)}

    try:
        ss = drik.sunset(jd, p)
        result["sunset"] = _clock_time(ss) if ss else "N/A"
    except Exception as e:
        result["sunset"] = {"error": error_payload(e)}

    try:
        mr = drik.moonrise(jd, p)
        result["moonrise"] = _clock_time(mr) if mr else "N/A"
    except Exception as e:
        result["moonrise"] = {"error": error_payload(e)}

    try:
        ms = drik.moonset(jd, p)
        result["moonset"] = _clock_time(ms) if ms else "N/A"
    except Exception as e:
        result["moonset"] = {"error": error_payload(e)}

    try:
        md = drik.midday(jd, p)
        result["midday"] = _clock_time(md) if md else "N/A"
    except Exception as e:
        result["midday"] = {"error": error_payload(e)}

    try:
        mn = drik.midnight(jd, p)
        result["midnight"] = _clock_time(mn) if mn is not None else "N/A"
    except Exception as e:
        result["midnight"] = {"error": error_payload(e)}

    return result


# ---------------------------------------------------------------------------
# get_rahu_kala
# ---------------------------------------------------------------------------


@mcp.tool
def get_rahu_kala(place: PlaceInput, date_time: DateTimeInput) -> RahuKalaResult:
    """Calculate inauspicious time periods: Rahu Kalam, Yamaganda Kala, and Gulika Kala.

    These are traditionally considered unfavourable periods for starting new ventures.
    Times are in local time (HH:MM:SS format).

    Args:
        place: Geographic location.
        date_time: Date for which to calculate.

    Returns:
        Dictionary with start and end times for each inauspicious period.
    """
    from jhora.panchanga import drik

    jd = to_julian_day(date_time)
    p = to_place(place)

    result: dict[str, Any] = {}

    try:
        rk = drik.raahu_kaalam(jd, p)
        if rk and len(rk) == 2:
            result["rahu_kalam"] = _period(rk)
    except Exception as e:
        result["rahu_kalam"] = {"error": error_payload(e)}

    try:
        yg = drik.yamaganda_kaalam(jd, p)
        if yg and len(yg) == 2:
            result["yamaganda_kalam"] = _period(yg)
    except Exception as e:
        result["yamaganda_kalam"] = {"error": error_payload(e)}

    try:
        gl = drik.gulikai_kaalam(jd, p)
        if gl and len(gl) == 2:
            result["gulika_kalam"] = _period(gl)
    except Exception as e:
        result["gulika_kalam"] = {"error": error_payload(e)}

    return result


# ---------------------------------------------------------------------------
# get_muhurtha
# ---------------------------------------------------------------------------


@mcp.tool
def get_muhurtha(place: PlaceInput, date_time: DateTimeInput) -> MuhurthaResult:
    """Calculate auspicious Muhurtha (time) periods for a given date and place.

    Returns timings for:
    - **Abhijit Muhurtha**: Most auspicious period near midday
    - **Brahma Muhurtha**: Pre-dawn auspicious period (~96 min before sunrise)
    - **Godhuli Muhurtha**: Dusk period (cow-dust hour)
    - **Vijaya Muhurtha**: Victory muhurtha
    - **Nishita Muhurtha**: Midnight period

    Also returns Durmuhurtha (inauspicious periods to avoid).

    Args:
        place: Geographic location.
        date_time: Date for which to calculate.

    Returns:
        Dictionary with start/end times for each muhurtha period.
    """
    from jhora.panchanga import drik

    jd = to_julian_day(date_time)
    p = to_place(place)

    result: dict[str, Any] = {}

    try:
        abh = drik.abhijit_muhurta(jd, p)
        if abh and len(abh) == 2:
            result["abhijit_muhurtha"] = _period(abh)
    except Exception as e:
        result["abhijit_muhurtha"] = {"error": error_payload(e)}

    try:
        dur = drik.durmuhurtam(jd, p)
        if dur:
            result["durmuhurtham"] = _period_list(dur)
    except Exception as e:
        result["durmuhurtham"] = {"error": error_payload(e)}

    try:
        bm = drik.brahma_muhurtha(jd, p)
        if bm and len(bm) == 2:
            result["brahma_muhurtha"] = _period(bm)
    except Exception as e:
        result["brahma_muhurtha"] = {"error": error_payload(e)}

    try:
        gm = drik.godhuli_muhurtha(jd, p)
        if gm and len(gm) == 2:
            result["godhuli_muhurtha"] = _period(gm)
    except Exception as e:
        result["godhuli_muhurtha"] = {"error": error_payload(e)}

    try:
        vm = drik.vijaya_muhurtha(jd, p)
        if vm and len(vm) == 2:
            result["vijaya_muhurtha"] = _period(vm)
    except Exception as e:
        result["vijaya_muhurtha"] = {"error": error_payload(e)}

    try:
        nm = drik.nishita_muhurtha(jd, p)
        if nm and len(nm) == 2:
            result["nishita_muhurtha"] = _period(nm)
    except Exception as e:
        result["nishita_muhurtha"] = {"error": error_payload(e)}

    return result


# ---------------------------------------------------------------------------
# get_planet_positions
# ---------------------------------------------------------------------------


@mcp.tool
def get_planet_positions(birth_data: BirthDataInput) -> PlanetPositionsResult:
    """Get sidereal (Vedic) planetary positions for a given date, time and place.

    Returns the Rasi (sign), degree within Rasi, Nakshatra, and Nakshatra Pada
    for each of the 9 classical planets (Sun through Ketu) plus the Ascendant (Lagna).

    Args:
        birth_data: Location, date, time, and ayanamsa mode.

    Returns:
        Dictionary with planet name as key, position details as value.
    """
    from jhora.horoscope.chart import charts
    from jhora.panchanga import drik

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {"planets": {}, "ascendant": {}}

    try:
        # Get ascendant
        asc = drik.ascendant(jd, place)
        if asc:
            asc_rasi = int(asc[0])
            asc_long = asc[1]
            result["ascendant"] = {
                "rasi": rasi_id_to_name(asc_rasi),
                "rasi_index": asc_rasi,
                "longitude_in_rasi": round(asc_long, 4),
                "total_longitude": round(asc_rasi * 30 + asc_long, 4),
                "nakshatra": nakshatra_id_to_name(
                    int((asc_rasi * 30 + asc_long) // (360 / 27)) + 1
                ),
                "pada": int(
                    ((asc_rasi * 30 + asc_long) % (360 / 27)) // (360 / 27 / 4)
                )
                + 1,
            }
    except Exception as e:
        result["ascendant"] = {"error": error_payload(e)}

    # Classic 9 planets: Sun(0) to Ketu(8). Use the same local-JD
    # charts.rasi_chart source as get_rasi_chart. drik.sidereal_longitude
    # explicitly requires UTC JD and therefore cannot be called with this
    # tool's local birth JD without a timezone conversion.
    try:
        for item in charts.rasi_chart(jd, place):
            if not isinstance(item, (list, tuple)) or len(item) != 2:
                continue
            pid, position = item
            if pid not in range(9) or not isinstance(position, (list, tuple)):
                continue
            rasi_idx, long_in_rasi = int(position[0]), float(position[1])
            total_long = rasi_idx * 30 + long_in_rasi
            nak_idx = int(total_long // (360 / 27)) + 1
            pada = int((total_long % (360 / 27)) // (360 / 27 / 4)) + 1
            pname = planet_id_to_name(pid)
            result["planets"][pname] = {
                "rasi": rasi_id_to_name(rasi_idx),
                "rasi_index": rasi_idx,
                "longitude_in_rasi": round(long_in_rasi, 4),
                "total_longitude": round(total_long, 4),
                "nakshatra": nakshatra_id_to_name(nak_idx),
                "nakshatra_index": nak_idx,
                "pada": pada,
            }
    except Exception as e:
        result["planets_error"] = error_payload(e)

    return result


# ---------------------------------------------------------------------------
# get_festivals
# ---------------------------------------------------------------------------


@mcp.tool
def get_festivals(place: PlaceInput, date_time: DateTimeInput) -> FestivalsResult:
    """Retrieve Hindu festivals and special days for a given date and location.

    Uses the PyJHora festival database (CSV) to look up festivals by date.

    Args:
        place: Geographic location (used for regional festivals).
        date_time: Date to check for festivals.

    Returns:
        Dictionary with list of festivals on the given date.
    """
    from jhora.panchanga import vratha

    jd = to_julian_day(date_time)
    p = to_place(place)
    dt = date_time

    result: dict[str, Any] = {"date": f"{dt.year}-{dt.month:02d}-{dt.day:02d}", "festivals": []}

    try:
        festivals = vratha.get_festivals_of_the_day(jd, p)
        if festivals:
            result["festivals"] = festivals if isinstance(festivals, list) else [str(festivals)]
        else:
            result["festivals"] = []
    except Exception as e:
        result["error"] = error_payload(e)

    return result
