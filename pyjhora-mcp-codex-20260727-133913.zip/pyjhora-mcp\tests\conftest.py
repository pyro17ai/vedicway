"""Shared pytest fixtures for PyJHora MCP server tests."""

import pytest

from pyjhora_mcp.models.schemas import (
    AyanamsaMode,
    BirthDataInput,
    CompatibilityInput,
    DateTimeInput,
    PlaceInput,
)


@pytest.fixture
def chennai_place() -> PlaceInput:
    """Chennai, India — a common reference location for Vedic astrology tests."""
    return PlaceInput(
        name="Chennai,IN",
        latitude=13.0878,
        longitude=80.2785,
        timezone=5.5,
    )


@pytest.fixture
def new_delhi_place() -> PlaceInput:
    """New Delhi, India."""
    return PlaceInput(
        name="New Delhi,IN",
        latitude=28.6139,
        longitude=77.2090,
        timezone=5.5,
    )


@pytest.fixture
def sample_date() -> DateTimeInput:
    """A fixed reference date: 15 Jan 2024, 10:30 AM IST."""
    return DateTimeInput(year=2024, month=1, day=15, hour=10, minute=30, second=0)


@pytest.fixture
def pvr_birth_date() -> DateTimeInput:
    """Sample birth date/time for test calculations."""
    return DateTimeInput(year=1970, month=1, day=1, hour=8, minute=30, second=0)


@pytest.fixture
def sample_birth_data(chennai_place, sample_date) -> BirthDataInput:
    """Sample birth data: Chennai, 15 Jan 2024, 10:30 AM."""
    return BirthDataInput(
        place=chennai_place,
        date_time=sample_date,
        ayanamsa=AyanamsaMode.LAHIRI,
    )


@pytest.fixture
def pvr_birth_data(chennai_place, pvr_birth_date) -> BirthDataInput:
    """Reference birth data (1970-01-01, Chennai) used for comparison tests."""
    return BirthDataInput(
        place=chennai_place,
        date_time=pvr_birth_date,
        ayanamsa=AyanamsaMode.LAHIRI,
    )


@pytest.fixture
def compatibility_input(chennai_place, new_delhi_place) -> CompatibilityInput:
    """Sample compatibility input: boy from Chennai (1990), girl from Delhi (1992)."""
    boy_birth = BirthDataInput(
        place=chennai_place,
        date_time=DateTimeInput(year=1990, month=6, day=15, hour=10, minute=0, second=0),
        ayanamsa=AyanamsaMode.LAHIRI,
    )
    girl_birth = BirthDataInput(
        place=new_delhi_place,
        date_time=DateTimeInput(year=1992, month=3, day=20, hour=14, minute=30, second=0),
        ayanamsa=AyanamsaMode.LAHIRI,
    )
    return CompatibilityInput(boy_birth=boy_birth, girl_birth=girl_birth)
