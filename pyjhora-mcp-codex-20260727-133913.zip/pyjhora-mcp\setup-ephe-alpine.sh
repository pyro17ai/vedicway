#!/usr/bin/env ash
# setup-ephe-alpine.sh — Download PyJHora Swiss Ephemeris data files (Alpine Linux)
#
# PyJHora v3.6.6+ does NOT include ephemeris (.se1) files in the PyPI package.
# This script clones only the ephe/ folder from the PyJHora GitHub repository.
#
# Usage:
#   ash setup-ephe-alpine.sh               # Downloads to ./ephe/
#   ash setup-ephe-alpine.sh /custom/path  # Downloads to a custom path

set -euo pipefail

EPHE_DIR="${1:-$(dirname "$0")/ephe}"
REPO_URL="https://github.com/naturalstupid/pyjhora"
# Use /var/tmp instead of /tmp to avoid tmpfs size limits on small VPS
TMP_DIR=$(mktemp -d -p /var/tmp)

cleanup() {
    rm -rf "$TMP_DIR"
}

trap cleanup EXIT

if ! command -v git >/dev/null 2>&1; then
    echo "Error: git is required but not installed."
    echo "Run: apk add git"
    exit 1
fi

echo ">>> Downloading PyJHora ephemeris data files..."
echo "    Target directory: $EPHE_DIR"
echo ""

# Download PyJHora repo (sparse checkout — only the ephe/ subdirectory)
git clone --no-checkout --depth 1 --filter=blob:none "$REPO_URL.git" "$TMP_DIR/pyjhora" 2>&1

cd "$TMP_DIR/pyjhora"
git sparse-checkout init --cone
git sparse-checkout set "src/jhora/data/ephe"
git checkout

# Create target directory and copy files
mkdir -p "$EPHE_DIR"
# Alpine ash has no mapfile — use find + wc
ephe_count=$(find "$TMP_DIR/pyjhora/src/jhora/data/ephe" -maxdepth 1 -type f | wc -l)
if [ "$ephe_count" -eq 0 ]; then
    echo "Error: no ephemeris files were found in the downloaded repository."
    exit 1
fi

cp -v "$TMP_DIR/pyjhora/src/jhora/data/ephe/"* "$EPHE_DIR/"

echo ""
echo ">>> Done! Ephemeris files downloaded to: $EPHE_DIR"
echo "    File count: $(find "$EPHE_DIR" -maxdepth 1 -type f | wc -l)"
echo ""
echo "Next steps:"
echo "  - For service:  sudo ash deploy-service-alpine.sh install"
