#!/usr/bin/env ash
# deploy-service-alpine.sh — Install/upgrade/uninstall pyjhora-mcp on Alpine Linux
#
# Manages: apk packages, OpenRC service, Caddy reverse proxy, ephemeris data
#
# Usage:
#   sudo ash ./deploy-service-alpine.sh install
#   sudo ash ./deploy-service-alpine.sh uninstall
#   sudo ash ./deploy-service-alpine.sh reinstall
#   sudo ash ./deploy-service-alpine.sh status
#   sudo ash ./deploy-service-alpine.sh logs

set -euo pipefail

APP_NAME="pyjhora-mcp"
APP_USER="pyjhora"
APP_GROUP="pyjhora"
APP_DIR="/opt/pyjhora-mcp"
INITD_FILE="/etc/init.d/${APP_NAME}"
CADDY_MAIN_FILE="/etc/caddy/Caddyfile"
CADDY_SNIPPET_DIR="/etc/caddy/Caddyfile.d"
CADDY_SNIPPET_FILE="${CADDY_SNIPPET_DIR}/${APP_NAME}.caddy"
ENV_FILE="${APP_DIR}/.env"
DOMAIN="${DOMAIN:-pyjhora-mcp.lairfrost.dev}"
APP_PORT="${APP_PORT:-8000}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

usage() {
    cat <<EOF
Usage: sudo ash ./deploy-service-alpine.sh <command>

Commands:
  install      Install/upgrade app, OpenRC service, and Caddy reverse proxy
  uninstall    Remove service, Caddy config, app files, and app user
  reinstall    Run uninstall followed by install
  start        Start the app service and Caddy reverse proxy
  stop         Stop the app service and Caddy reverse proxy
  restart      Restart the app service and reload Caddy
  status       Show service and Caddy status
  logs         Tail service logs

Environment variables:
  DOMAIN       Domain name for Caddy reverse proxy (default: ${DOMAIN})
  APP_PORT     Internal app port (default: ${APP_PORT})

Env file:
  ${ENV_FILE}
  Add API_KEY there to enable Bearer token authentication.
EOF
}

require_root() {
    if [ "$(id -u)" -ne 0 ]; then
        echo "This script must be run as root (use sudo / doas)."
        exit 1
    fi
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# ── Package installation ──────────────────────────────────────────────

install_system_packages() {
    if ! command_exists apk; then
        echo "This script is for Alpine Linux (apk required)."
        exit 1
    fi

    # Ensure community repo is enabled (needed for caddy, rsync)
    if ! grep -q "^.*community" /etc/apk/repositories 2>/dev/null; then
        echo ">>> Enabling community repository..."
        sed -i 's|^#\(.*\/community\)$|\1|' /etc/apk/repositories
        apk update
    fi

    apk update
    apk add \
        ca-certificates \
        curl \
        git \
        python3 \
        py3-pip \
        py3-virtualenv \
        build-base \
        gcc \
        musl-dev \
        swig \
        rsync \
        libstdc++ \
        unzip

    if ! command_exists caddy; then
        if ! grep -q "^.*community" /etc/apk/repositories; then
            sed -i 's|^#\(.*\/community\)$|\1|' /etc/apk/repositories
            apk update
        fi
        apk add caddy
    fi
}

# ── User management ───────────────────────────────────────────────────

ensure_app_user() {
    if ! getent group "${APP_GROUP}" >/dev/null 2>&1; then
        addgroup -S "${APP_GROUP}"
    fi

    if ! id -u "${APP_USER}" >/dev/null 2>&1; then
        adduser -S -G "${APP_GROUP}" -h "/var/lib/${APP_NAME}" -s /sbin/nologin -D "${APP_USER}"
    fi
}

# ── Source sync ───────────────────────────────────────────────────────

sync_app_source() {
    mkdir -p "${APP_DIR}"
    rsync -a --delete \
        --exclude '.git' \
        --exclude '.venv' \
        --exclude '__pycache__' \
        --exclude '.pytest_cache' \
        "${SCRIPT_DIR}/" "${APP_DIR}/"
    chown -R "${APP_USER}:${APP_GROUP}" "${APP_DIR}"
}

# ── Python environment ────────────────────────────────────────────────

setup_python_env() {
    if [ ! -d "${APP_DIR}/.venv" ]; then
        su -s /bin/ash -c "python3 -m venv ${APP_DIR}/.venv" "${APP_USER}"
    fi

    su -s /bin/ash -c "${APP_DIR}/.venv/bin/pip install --upgrade pip setuptools wheel" "${APP_USER}"
    su -s /bin/ash -c "${APP_DIR}/.venv/bin/pip install -r ${APP_DIR}/requirements.txt" "${APP_USER}"
    su -s /bin/ash -c "${APP_DIR}/.venv/bin/pip install -e ${APP_DIR}" "${APP_USER}"
}

# ── Ephemeris data ────────────────────────────────────────────────────

install_ephemeris_data() {
    local ephe_source_dir="${APP_DIR}/ephe"
    local tmp_ephe_dir=""

    if [ ! -d "${ephe_source_dir}" ] || [ -z "$(find "${ephe_source_dir}" -maxdepth 1 -type f -print -quit 2>/dev/null)" ]; then
        tmp_ephe_dir="$(mktemp -d)"
        ash "${APP_DIR}/setup-ephe-alpine.sh" "${tmp_ephe_dir}"
        ephe_source_dir="${tmp_ephe_dir}"
    fi

    local jhora_ephe_dir
    jhora_ephe_dir="$("${APP_DIR}/.venv/bin/python" -c 'import os, jhora; print(os.path.join(os.path.dirname(jhora.__file__), "data", "ephe"))')"
    mkdir -p "${jhora_ephe_dir}"
    cp -f "${ephe_source_dir}/"* "${jhora_ephe_dir}/"

    if [ -n "${tmp_ephe_dir}" ]; then
        rm -rf "${tmp_ephe_dir}"
    fi
}

# ── Environment file ──────────────────────────────────────────────────

write_env_file() {
    if [ ! -f "${ENV_FILE}" ]; then
        cat > "${ENV_FILE}" <<EOF
# Environment for ${APP_NAME}
# Set this to require Authorization: Bearer <token>
API_KEY=change_this_to_a_long_random_secret

# Optional: override internal app port used by service
# PORT=${APP_PORT}
EOF
        chmod 600 "${ENV_FILE}"
        chown "${APP_USER}:${APP_GROUP}" "${ENV_FILE}"
    fi
}

# ── OpenRC service ────────────────────────────────────────────────────

write_openrc_service() {
    cat > "${INITD_FILE}" <<INITEOF
#!/sbin/openrc-run
# /etc/init.d/pyjhora-mcp — OpenRC service for PyJHora MCP Server

name="pyjhora-mcp"
description="PyJHora Vedic Astrology MCP Server"
command="${APP_DIR}/.venv/bin/python"
command_args="-m pyjhora_mcp.server"
command_user="${APP_USER}:${APP_GROUP}"
command_background=true
pidfile="/run/${name}.pid"
output_log="/var/log/${name}/stdout.log"
error_log="/var/log/${name}/stderr.log"

PORT="${APP_PORT}"
if [ -f "${ENV_FILE}" ]; then
    . "${ENV_FILE}"
fi
export PORT API_KEY

start_pre() {
    checkpath -d -m 0755 -o "${APP_USER}:${APP_GROUP}" "/var/log/${name}"
}
INITEOF

    chmod 755 "${INITD_FILE}"

    mkdir -p "/var/log/${APP_NAME}"
    chown -R "${APP_USER}:${APP_GROUP}" "/var/log/${APP_NAME}"

    rc-update add "${APP_NAME}" default
    rc-service "${APP_NAME}" restart || rc-service "${APP_NAME}" start
}

# ── Caddy reverse proxy ───────────────────────────────────────────────

write_caddy_config() {
    mkdir -p "${CADDY_SNIPPET_DIR}"

    cat > "${CADDY_SNIPPET_FILE}" <<EOF
${DOMAIN} {
    encode zstd gzip
    reverse_proxy 127.0.0.1:${APP_PORT}
}
EOF

    if [ ! -f "${CADDY_MAIN_FILE}" ]; then
        echo "${CADDY_SNIPPET_DIR} not found and main Caddyfile missing."
        exit 1
    fi

    if ! grep -q "import ${CADDY_SNIPPET_DIR}/\*\.caddy" "${CADDY_MAIN_FILE}"; then
        cp "${CADDY_MAIN_FILE}" "${CADDY_MAIN_FILE}.bak.$(date +%s)"
        {
            echo ""
            echo "import ${CADDY_SNIPPET_DIR}/*.caddy"
        } >> "${CADDY_MAIN_FILE}"
    fi

    caddy validate --config "${CADDY_MAIN_FILE}" 2>/dev/null || true
    rc-update add caddy default
    rc-service caddy restart || rc-service caddy start
}

# ── Install / Uninstall ───────────────────────────────────────────────

install_all() {
    install_system_packages
    ensure_app_user
    sync_app_source
    setup_python_env
    install_ephemeris_data
    write_env_file
    write_openrc_service
    write_caddy_config

    echo ""
    echo "Installation complete."
    echo "Service:   rc-service ${APP_NAME} status"
    echo "Caddy:     rc-service caddy status"
    echo "Env file:  ${ENV_FILE}"
    echo "Health:    curl -i https://${DOMAIN}/"
}

uninstall_all() {
    if rc-service "${APP_NAME}" status >/dev/null 2>&1; then
        rc-service "${APP_NAME}" stop || true
    fi
    rc-update del "${APP_NAME}" default 2>/dev/null || true
    rm -f "${INITD_FILE}"

    rm -f "${CADDY_SNIPPET_FILE}"
    if command_exists caddy && [ -f "${CADDY_MAIN_FILE}" ]; then
        caddy validate --config "${CADDY_MAIN_FILE}" 2>/dev/null || true
        rc-service caddy restart || true
    fi

    rm -rf "${APP_DIR}"

    if [ "${PURGE_ENV:-0}" = "1" ]; then
        rm -rf "${ENV_DIR}"
    fi
    if getent group "${APP_GROUP}" >/dev/null 2>&1; then
        delgroup "${APP_GROUP}" 2>/dev/null || true
    fi

    echo "Uninstall complete."
    if [ "${PURGE_ENV:-0}" != "1" ]; then
        echo "Kept env file at ${ENV_FILE} (set PURGE_ENV=1 to remove on uninstall)."
    fi
}

start_all() {
    rc-service "${APP_NAME}" start || true
    rc-service caddy start || true
    echo "Service started."
}

stop_all() {
    rc-service caddy stop || true
    rc-service "${APP_NAME}" stop || true
    echo "Service stopped."
}

restart_all() {
    rc-service "${APP_NAME}" restart || true
    if command_exists caddy; then
        rc-service caddy restart || true
    fi
    echo "Service restarted."
}

status_all() {
    echo "=== ${APP_NAME} ==="
    rc-service "${APP_NAME}" status 2>&1 || true
}

logs() {
    tail -f "/var/log/${APP_NAME}/stdout.log" "/var/log/${APP_NAME}/stderr.log"
}

# ── Main ──────────────────────────────────────────────────────────────

main() {
    local cmd="${1:-}"

    case "${cmd}" in
        install)
            require_root
            install_all
            ;;
        uninstall)
            require_root
            uninstall_all
            ;;
        reinstall)
            require_root
            uninstall_all
            install_all
            ;;
        start)
            require_root
            start_all
            ;;
        stop)
            require_root
            stop_all
            ;;
        restart)
            require_root
            restart_all
            ;;
        status)
            status_all
            ;;
        logs)
            logs
            ;;
        *)
            usage
            exit 1
            ;;
    esac
}

main "$@"
