"""Conversion helpers between MCP Pydantic models and PyJHora internal types."""

from __future__ import annotations

from collections import namedtuple
from typing import Any

# ---------------------------------------------------------------------------
# Lazy PyJHora imports — only called at runtime so that import errors surface
# with a clear message when the package is not installed / ephe files missing.
# ---------------------------------------------------------------------------

_PLANET_NAMES = [
    "Sun",
    "Moon",
    "Mars",
    "Mercury",
    "Jupiter",
    "Venus",
    "Saturn",
    "Rahu",
    "Ketu",
    "Uranus",
    "Neptune",
    "Pluto",
    "Mean Ascendant (Lagna)",
]

_RASI_NAMES = [
    "Aries",
    "Taurus",
    "Gemini",
    "Cancer",
    "Leo",
    "Virgo",
    "Libra",
    "Scorpio",
    "Sagittarius",
    "Capricorn",
    "Aquarius",
    "Pisces",
]

_NAKSHATRA_NAMES = [
    "Aswini",
    "Bharani",
    "Krittika",
    "Rohini",
    "Mrigasira",
    "Ardra",
    "Punarvasu",
    "Pushya",
    "Aslesha",
    "Magha",
    "Purva Phalguni",
    "Uttara Phalguni",
    "Hasta",
    "Chitra",
    "Swati",
    "Vishakha",
    "Anuradha",
    "Jyeshtha",
    "Mula",
    "Purva Ashadha",
    "Uttara Ashadha",
    "Sravana",
    "Dhanishtha",
    "Shatabhisha",
    "Purva Bhadrapada",
    "Uttara Bhadrapada",
    "Revati",
]

_TITHI_NAMES = [
    "Pratipada",
    "Dvitiya",
    "Tritiya",
    "Chaturthi",
    "Panchami",
    "Shashthi",
    "Saptami",
    "Ashtami",
    "Navami",
    "Dashami",
    "Ekadashi",
    "Dvadashi",
    "Trayodashi",
    "Chaturdashi",
    "Purnima / Amavasya",
]

_YOGA_NAMES = [
    "Vishkambha",
    "Priti",
    "Ayushman",
    "Saubhagya",
    "Shobhana",
    "Atiganda",
    "Sukarman",
    "Dhriti",
    "Shula",
    "Ganda",
    "Vriddhi",
    "Dhruva",
    "Vyaghata",
    "Harshana",
    "Vajra",
    "Siddhi",
    "Vyatipata",
    "Variyan",
    "Parigha",
    "Shiva",
    "Siddha",
    "Sadhya",
    "Shubha",
    "Shukla",
    "Brahma",
    "Indra",
    "Vaidhriti",
]

_KARANA_NAMES = [
    "Bava",
    "Balava",
    "Kaulava",
    "Taitila",
    "Garaja",
    "Vanija",
    "Vishti",
    "Bava",
    "Balava",
    "Kaulava",
    "Taitila",  # Repeating group
    "Shakuni",
    "Chatushpada",
    "Naga",
    "Kimstughna",  # Fixed karanas
]

_VAARA_NAMES = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
]

_MASA_NAMES = [
    "Chaitra",
    "Vaishakha",
    "Jyeshtha",
    "Ashadha",
    "Shravana",
    "Bhadrapada",
    "Ashwin",
    "Kartika",
    "Margashirsha",
    "Pausha",
    "Magha",
    "Phalguna",
]

_SAMVATSARA_NAMES = [
    "Prabhava",
    "Vibhava",
    "Shukla",
    "Pramoda",
    "Prajotpatti",
    "Angirasa",
    "Shrimukha",
    "Bhava",
    "Yuva",
    "Dhata",
    "Ishvara",
    "Bahudhanya",
    "Pramathi",
    "Vikrama",
    "Vrisha",
    "Chitrabhanu",
    "Subhanu",
    "Tarana",
    "Parthiva",
    "Vyaya",
    "Sarvajit",
    "Sarvadharin",
    "Virodhi",
    "Vikriti",
    "Khara",
    "Nandana",
    "Vijaya",
    "Jaya",
    "Manmatha",
    "Durmukhi",
    "Hevilambi",
    "Vilambi",
    "Vikari",
    "Sharvari",
    "Plava",
    "Shubhakrit",
    "Shobhakrit",
    "Krodhi",
    "Vishvavasu",
    "Parabhava",
    "Plavanga",
    "Kilaka",
    "Saumya",
    "Sadharana",
    "Virodhakrit",
    "Paridhavin",
    "Pramadin",
    "Ananda",
    "Rakshasa",
    "Nala",
    "Pingala",
    "Kalayukti",
    "Siddharthi",
    "Raudra",
    "Durmati",
    "Dundubhi",
    "Rudhirodgarin",
    "Raktakshi",
    "Krodhana",
    "Akshaya",
]

# Place namedtuple matching PyJHora's internal structure
Place = namedtuple("Place", ["place_name", "latitude", "longitude", "timezone"])


def to_place(p: Any) -> Place:
    """Convert a PlaceInput Pydantic model to a PyJHora Place namedtuple."""
    ensure_ephemeris_path()
    return Place(p.name, p.latitude, p.longitude, p.timezone)


def to_julian_day(dt: Any) -> float:
    """Convert a DateTimeInput Pydantic model to a Julian Day Number."""
    ensure_ephemeris_path()
    from jhora import utils
    from jhora.panchanga.drik import Date

    date = Date(dt.year, dt.month, dt.day)
    time_of_day = (dt.hour, dt.minute, dt.second)
    return utils.julian_day_number(date, time_of_day)


def set_ayanamsa(mode_str: str) -> None:
    """Set the ayanamsa mode for all subsequent calculations."""
    ensure_ephemeris_path()
    from jhora.panchanga import drik

    drik.set_ayanamsa_mode(mode_str)


def ensure_ephemeris_path() -> str:
    """Configure and validate the Swiss Ephemeris directory for this runtime."""
    from pathlib import Path

    import swisseph as swe
    from jhora import const

    candidates = (
        Path(const._EPHIMERIDE_DATA_PATH).resolve(),
        Path(const._ephe_path).resolve(),
    )
    path = next((candidate for candidate in candidates if candidate.is_dir()), None)
    if path is None:
        raise RuntimeError("Swiss Ephemeris directory is not available")

    required_file = path / "seplm48.se1"
    if not required_file.is_file():
        raise RuntimeError(f"Required Swiss Ephemeris file is missing: {required_file.name}")

    swe.set_ephe_path(path.as_posix())
    return str(path)


def format_time(hours: float) -> str:
    """Convert fractional hours to HH:MM:SS string."""
    if hours is None:
        return "N/A"
    if isinstance(hours, str):
        return hours
    # Handle times > 24 (past midnight, Hindu convention)
    total_seconds = int(round(float(hours) * 3600))
    h = total_seconds // 3600
    m = (total_seconds % 3600) // 60
    s = total_seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def planet_id_to_name(pid: int) -> str:
    """Map a PyJHora planet index to a human-readable name."""
    if 0 <= pid < len(_PLANET_NAMES):
        return _PLANET_NAMES[pid]
    return f"Planet-{pid}"


def rasi_id_to_name(rid: int) -> str:
    """Map a rasi index (0–11) to a sign name."""
    if 0 <= rid < len(_RASI_NAMES):
        return _RASI_NAMES[rid]
    return f"Rasi-{rid}"


def nakshatra_id_to_name(nid: int) -> str:
    """Map a nakshatra index (1–27) to a name (1-based)."""
    idx = (nid - 1) % 27
    return _NAKSHATRA_NAMES[idx]


def tithi_id_to_name(tid: int) -> str:
    """Map a tithi index (1–30) to a name."""
    # Tithis 1-15 are Shukla Paksha, 16-30 are Krishna Paksha
    if 1 <= tid <= 15:
        return f"Shukla {_TITHI_NAMES[tid - 1]}"
    elif 16 <= tid <= 30:
        idx = tid - 16
        if idx < len(_TITHI_NAMES):
            return f"Krishna {_TITHI_NAMES[idx]}"
    return f"Tithi-{tid}"


def yoga_id_to_name(yid: int) -> str:
    """Map a yoga index (1–27) to a name (1-based)."""
    idx = (yid - 1) % 27
    return _YOGA_NAMES[idx]


def karana_id_to_name(kid: int) -> str:
    """Map a karana index to a name."""
    if 1 <= kid <= len(_KARANA_NAMES):
        return _KARANA_NAMES[kid - 1]
    return f"Karana-{kid}"


def vaara_id_to_name(vid: int) -> str:
    """Map a vaara index (0=Sunday) to a day name."""
    return _VAARA_NAMES[vid % 7]


def masa_id_to_name(mid: int) -> str:
    """Map a masa / lunar month index (1-based) to a name."""
    idx = (mid - 1) % 12
    return _MASA_NAMES[idx]


def samvatsara_id_to_name(sid: int) -> str:
    """Map a samvatsara index to a name."""
    idx = (sid - 1) % 60
    return _SAMVATSARA_NAMES[idx]


def safe_call(fn, *args, error_context: str = "", **kwargs) -> dict:
    """
    Safely call a PyJHora function, returning a structured dict.

    Returns:
        {"success": True, "data": <result>}  on success
        {"success": False, "error": <msg>}   on failure
    """
    try:
        result = fn(*args, **kwargs)
        return {"success": True, "data": result}
    except Exception as exc:
        ctx = f" [{error_context}]" if error_context else ""
        return {
            "success": False,
            "error": error_payload(exc, code="SAFE_CALL_ERROR"),
            "error_context": ctx.strip(" []") or None,
        }


def error_payload(
    exc: Exception,
    code: str = "CALCULATION_ERROR",
    recoverable: bool = True,
) -> dict[str, Any]:
    """Return the common machine-readable error shape used by every tool."""
    return {
        "code": code,
        "type": type(exc).__name__,
        "message": str(exc),
        "recoverable": recoverable,
    }
