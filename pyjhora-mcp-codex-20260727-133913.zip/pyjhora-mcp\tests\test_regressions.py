import asyncio
from pathlib import Path

import pytest

from pyjhora_mcp.tools.horoscope import get_rasi_chart
from pyjhora_mcp.tools.panchanga import get_panchanga, get_planet_positions


def test_planet_positions_matches_canonical_rasi_chart(sample_birth_data):
    chart = get_rasi_chart(sample_birth_data)
    positions = get_planet_positions(sample_birth_data)
    chart_by_name = {
        item["planet"]: item
        for item in chart["planets"]
        if item["planet"] in positions["planets"]
    }

    for name, position in positions["planets"].items():
        assert position["rasi"] == chart_by_name[name]["rasi"]
        assert position["total_longitude"] == pytest.approx(
            chart_by_name[name]["total_longitude"],
            abs=0.0001,
        )


def test_ephemeris_path_is_explicit_and_contains_required_file():
    from pyjhora_mcp.utils import converters

    ensure_ephemeris_path = getattr(converters, "ensure_ephemeris_path", None)
    assert callable(ensure_ephemeris_path)
    path = Path(ensure_ephemeris_path())
    assert path.is_dir()
    assert (path / "seplm48.se1").is_file()


def test_panchanga_errors_are_structured(sample_birth_data):
    result = get_panchanga(sample_birth_data)
    for value in result.values():
        if isinstance(value, dict) and "error" in value:
            assert isinstance(value["error"], dict)
            assert {"code", "message", "type"} <= value["error"].keys()


def test_error_payload_has_stable_contract():
    from pyjhora_mcp.utils.converters import error_payload

    error = error_payload(ValueError("bad input"), code="VALIDATION_ERROR", recoverable=False)

    assert error == {
        "code": "VALIDATION_ERROR",
        "type": "ValueError",
        "message": "bad input",
        "recoverable": False,
    }


def test_registered_tools_expose_detailed_output_schemas():
    from pyjhora_mcp.server import mcp

    tools = asyncio.run(mcp.list_tools())
    assert len(tools) == 22
    assert all(tool.output_schema.get("properties") for tool in tools)
