# tools/ — MCP Tool Modules

**Generated:** 2026-03-16
**Commit:** 09486f3

## OVERVIEW

Vedic astrology MCP tools organized as FastMCP sub-routers. Each module creates its own `FastMCP` instance and exports tools via `@mcp.tool` decorator.

## STRUCTURE

```
tools/
├── __init__.py      # Empty (router mounting via server.py)
├── panchanga.py     # 6 tools: tithi, nakshatra, yoga, karana, sunrise, muhurtha
├── horoscope.py     # 5 tools: rasi_chart, divisional_chart, special_lagnas, ashtakavarga, bhava_chart
├── dasha.py         # 4 tools: vimsottari, yogini, ashtottari, narayana dasha
├── compatibility.py # 1 tool: marriage compatibility (koota matching)
├── yoga.py          # 3 tools: yogas, doshas, raja_yogas
└── strength.py      # 3 tools: shadbala, bhava_bala, vimsopaka_bala
```

## WHERE TO LOOK

| Task | File | Key Function |
|------|------|--------------|
| Add panchanga tool | `panchanga.py` | `@mcp.tool` decorator pattern |
| Add chart calculation | `horoscope.py` | `charts.rasi_chart()` wrapper |
| Add dasha period tool | `dasha.py` | `dasha.vimsottari_dasha()` wrapper |
| Debug tool error | Any tool file | Check `safe_call()` wrapper in converters.py |
| Understand input models | `models/schemas.py` | `BirthDataInput`, `PlaceInput` |
| Find conversion helpers | `utils/converters.py` | `to_julian_day()`, `set_ayanamsa()` |

## CONVENTIONS

### Tool Registration Pattern
```python
from fastmcp import FastMCP
mcp = FastMCP(name="Tool Category Name")

@mcp.tool
def tool_name(birth_data: BirthDataInput) -> dict[str, Any]:
    """Docstring with Args/Returns."""
    # Implementation
```

### Error Handling
- Wrap all PyJHora calls in try/except
- Preserve partial responses when one field fails
- Return `{"error": {"code": ..., "type": ..., "message": ..., "recoverable": ...}}` for individual fields
- Use `error_payload()` or `safe_call()` from `converters.py`

### Input Models
- All birth-related tools use `BirthDataInput` (place + date_time + ayanamsa)
- Place-only tools use `PlaceInput` + `DateTimeInput` separately
- Always set ayanamsa before calculations: `set_ayanamsa(birth_data.ayanamsa.value)`

### Output Format
- Annotate each tool with its named `TypedDict` result from `models/schemas.py`; FastMCP publishes the output schema from this annotation
- Return an ordinary dictionary at runtime, preserving the established field names
- Times in `HH:MM:SS` format (use `format_time()` helper)
- IDs converted to human-readable names via `*_id_to_name()` helpers

### Lazy Imports
```python
# Import PyJHora inside functions (not at module level)
from jhora.panchanga import drik
from jhora.horoscope.chart import charts
```

## ANTI-PATTERNS (THIS PROJECT)

- **NO** mock objects in tests — integration tests call actual PyJHora
- **NO** `raise` exceptions from tools — return error dict instead
- **NO** print/logging in tool code — let caller handle output
- **NO** caching implementation — Swiss ephemeris handles this internally

## PATTERNS BY FILE

### panchanga.py (453 lines)
- Most complex — 6 tools with multiple PyJHora functions each
- `get_panchanga()` returns all 5 limbs + masa + samvatsara + ritu
- Each section wrapped in try/except for partial failure handling

### horoscope.py
- Chart calculations with divisional chart support
- `get_rasi_chart()` returns ascendant + classic and outer-planet entries when PyJHora returns them
- `get_divisional_chart()` uses `DivisionalChart` enum from schemas

### dasha.py (280 lines)
- Dasha period calculations
- All dashas return period lists with start/end dates
- `include_antara`, `include_pratyantara` parameters for depth

### compatibility.py (126 lines)
- Single tool: `get_compatibility()`
- Returns Ashta Koota score + Dasa Porutham
- Uses `compatibility_input` fixture in tests

### yoga.py (228 lines)
- 3 tools: `get_yogas()`, `get_doshas()`, `get_raja_yogas()`
- Returns list of detected yogas/doshas with descriptions

### strength.py (237 lines)
- 3 tools: `get_shadbala()`, `get_bhava_bala()`, `get_vimsopaka_bala()`
- Complex strength calculations with multiple components
