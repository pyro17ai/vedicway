"""Tests for horoscope chart tools."""

from pyjhora_mcp.tools.horoscope import (
    get_ashtakavarga,
    get_divisional_chart,
    get_rasi_chart,
    get_special_lagnas,
)


class TestGetRasiChart:
    """Tests for the get_rasi_chart tool."""

    def test_returns_ascendant(self, sample_birth_data):
        result = get_rasi_chart(sample_birth_data)
        assert "ascendant" in result
        asc = result["ascendant"]
        assert "error" not in asc
        assert "rasi" in asc
        assert 0 <= asc["rasi_index"] <= 11

    def test_returns_planets(self, sample_birth_data):
        result = get_rasi_chart(sample_birth_data)
        assert "planets" in result
        assert len(result["planets"]) > 0

    def test_planet_structure(self, sample_birth_data):
        result = get_rasi_chart(sample_birth_data)
        for planet in result["planets"]:
            assert "planet" in planet
            assert "rasi" in planet
            assert "rasi_index" in planet
            assert "longitude_in_rasi" in planet
            assert 0 <= planet["rasi_index"] <= 11
            assert 0 <= planet["longitude_in_rasi"] < 30

    def test_chart_type_label(self, sample_birth_data):
        result = get_rasi_chart(sample_birth_data)
        assert "D1" in result.get("chart_type", "")

    def test_ayanamsa_reflected(self, sample_birth_data):
        result = get_rasi_chart(sample_birth_data)
        assert result.get("ayanamsa") == "LAHIRI"


class TestGetDivisionalChart:
    """Tests for the get_divisional_chart tool."""

    def test_navamsa_d9(self, sample_birth_data):
        result = get_divisional_chart(sample_birth_data, divisor=9)
        assert result.get("divisor") == 9
        assert "planets" in result

    def test_drekkana_d3(self, sample_birth_data):
        result = get_divisional_chart(sample_birth_data, divisor=3)
        assert result.get("divisor") == 3

    def test_planet_positions_valid(self, sample_birth_data):
        result = get_divisional_chart(sample_birth_data, divisor=9)
        for planet in result.get("planets", []):
            if "rasi_index" in planet:
                assert 0 <= planet["rasi_index"] <= 11

    def test_default_divisor_is_9(self, sample_birth_data):
        result = get_divisional_chart(sample_birth_data)
        assert result.get("divisor") == 9


class TestGetSpecialLagnas:
    """Tests for the get_special_lagnas tool."""

    def test_returns_hora_lagna(self, sample_birth_data):
        result = get_special_lagnas(sample_birth_data)
        assert "hora_lagna" in result

    def test_returns_ghati_lagna(self, sample_birth_data):
        result = get_special_lagnas(sample_birth_data)
        assert "ghati_lagna" in result

    def test_lagna_rasi_in_valid_range(self, sample_birth_data):
        result = get_special_lagnas(sample_birth_data)
        for lagna_name, lagna_data in result.items():
            if isinstance(lagna_data, dict) and "rasi_index" in lagna_data:
                assert 0 <= lagna_data["rasi_index"] <= 11, f"{lagna_name} rasi index out of range"


class TestGetAshtakavarga:
    """Tests for the get_ashtakavarga tool."""

    def test_returns_structure(self, sample_birth_data):
        result = get_ashtakavarga(sample_birth_data)
        # Either bhinnashtakavarga or an error should be present
        assert (
            "bhinnashtakavarga" in result
            or "error" in result
            or "bhinnashtakavarga_error" in result
        )

    def test_samudaya_has_12_houses(self, sample_birth_data):
        result = get_ashtakavarga(sample_birth_data)
        samudaya = result.get("samudaya_ashtakavarga")
        if samudaya:
            assert len(samudaya) == 12, "Samudaya AV should have 12 houses"

    def test_bindus_in_valid_range(self, sample_birth_data):
        result = get_ashtakavarga(sample_birth_data)
        samudaya = result.get("samudaya_ashtakavarga")
        if samudaya:
            for house, bindus in samudaya.items():
                if isinstance(bindus, (int, float)):
                    assert 0 <= bindus <= 337, f"Samudaya bindus out of range for {house}"
