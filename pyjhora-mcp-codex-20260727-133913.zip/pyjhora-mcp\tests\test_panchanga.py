"""Tests for panchanga tools."""

from pyjhora_mcp.tools.panchanga import (
    get_panchanga,
    get_planet_positions,
    get_rahu_kala,
    get_sunrise_sunset,
)


class TestGetPanchanga:
    """Tests for the get_panchanga tool."""

    def test_returns_all_five_limbs(self, sample_birth_data):
        result = get_panchanga(sample_birth_data)
        assert "tithi" in result, "Tithi should be present"
        assert "nakshatra" in result, "Nakshatra should be present"
        assert "yoga" in result, "Yoga should be present"
        assert "karana" in result, "Karana should be present"
        assert "vaara" in result, "Vaara should be present"

    def test_tithi_has_required_fields(self, sample_birth_data):
        result = get_panchanga(sample_birth_data)
        tithi = result.get("tithi", {})
        assert "error" not in tithi, f"Tithi error: {tithi.get('error')}"
        assert "index" in tithi
        assert "name" in tithi
        assert 1 <= tithi["index"] <= 30, "Tithi index should be 1–30"

    def test_nakshatra_has_required_fields(self, sample_birth_data):
        result = get_panchanga(sample_birth_data)
        nak = result.get("nakshatra", {})
        assert "error" not in nak, f"Nakshatra error: {nak.get('error')}"
        assert "index" in nak
        assert "name" in nak
        assert 1 <= nak["index"] <= 27, "Nakshatra index should be 1–27"

    def test_vaara_is_string(self, sample_birth_data):
        result = get_panchanga(sample_birth_data)
        assert isinstance(result["vaara"], str), "Vaara should be a string"
        valid_vaaras = [
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
        ]
        assert result["vaara"] in valid_vaaras, f"Invalid vaara: {result['vaara']}"

    def test_yoga_index_valid(self, sample_birth_data):
        result = get_panchanga(sample_birth_data)
        yoga = result.get("yoga", {})
        if "error" not in yoga and "index" in yoga:
            assert 1 <= yoga["index"] <= 27, "Yoga index should be 1–27"

    def test_january_15_2024_is_monday(self, sample_birth_data):
        """2024-01-15 is a Monday."""
        result = get_panchanga(sample_birth_data)
        assert result["vaara"] == "Monday", f"2024-01-15 should be Monday, got {result['vaara']}"


class TestGetSunriseSunset:
    """Tests for the get_sunrise_sunset tool."""

    def test_returns_sunrise_and_sunset(self, chennai_place, sample_date):
        result = get_sunrise_sunset(chennai_place, sample_date)
        assert "sunrise" in result
        assert "sunset" in result

    def test_sunrise_before_sunset(self, chennai_place, sample_date):
        result = get_sunrise_sunset(chennai_place, sample_date)
        sr = result.get("sunrise", "")
        ss = result.get("sunset", "")
        if isinstance(sr, str) and isinstance(ss, str) and sr != "N/A" and ss != "N/A":
            # Sunrise should be before sunset (string comparison works for HH:MM:SS)
            assert sr < ss, f"Sunrise {sr} should be before sunset {ss}"

    def test_moonrise_present(self, chennai_place, sample_date):
        result = get_sunrise_sunset(chennai_place, sample_date)
        assert "moonrise" in result


class TestGetRahuKala:
    """Tests for the get_rahu_kala tool."""

    def test_returns_rahu_kalam(self, chennai_place, sample_date):
        result = get_rahu_kala(chennai_place, sample_date)
        assert "rahu_kalam" in result
        if "error" not in result.get("rahu_kalam", {}):
            rk = result["rahu_kalam"]
            assert "start" in rk
            assert "end" in rk

    def test_returns_yamaganda(self, chennai_place, sample_date):
        result = get_rahu_kala(chennai_place, sample_date)
        assert "yamaganda_kalam" in result

    def test_returns_gulika(self, chennai_place, sample_date):
        result = get_rahu_kala(chennai_place, sample_date)
        assert "gulika_kalam" in result


class TestGetPlanetPositions:
    """Tests for the get_planet_positions tool."""

    def test_returns_ascendant(self, sample_birth_data):
        result = get_planet_positions(sample_birth_data)
        assert "ascendant" in result
        asc = result["ascendant"]
        assert "error" not in asc, f"Ascendant error: {asc}"
        assert "rasi" in asc
        assert 0 <= asc["rasi_index"] <= 11

    def test_returns_all_nine_planets(self, sample_birth_data):
        result = get_planet_positions(sample_birth_data)
        planets = result.get("planets", {})
        planet_names = [
            "Sun",
            "Moon",
            "Mars",
            "Mercury",
            "Jupiter",
            "Venus",
            "Saturn",
            "Rahu",
            "Ketu",
        ]
        for pname in planet_names:
            assert pname in planets, f"{pname} should be in planet positions"

    def test_planet_longitudes_in_range(self, sample_birth_data):
        result = get_planet_positions(sample_birth_data)
        for pname, pos in result.get("planets", {}).items():
            if "error" not in pos:
                assert 0 <= pos["total_longitude"] < 360, f"{pname} total longitude out of range"
                assert 0 <= pos["longitude_in_rasi"] < 30, f"{pname} rasi longitude out of range"
