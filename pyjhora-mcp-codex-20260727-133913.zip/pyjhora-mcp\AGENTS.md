# AGENTS.md - pyjhora-mcp Project Knowledge Base

## Project Overview

This is an MCP (Model Context Protocol) server that wraps PyJHora, a comprehensive Vedic Astrology Python library. The server exposes astrological calculations as tools for LLM integration using FastMCP framework.

### Target Library: PyJHora
- **PyPI Package**: `pip install PyJHora`
- **Version**: 4.7.0
- **Purpose**: Vedic astrology calculations including panchanga, divisional charts, dasha periods, compatibility matching, yogas, and shadbala calculations
- **Key Dependency**: `pyswisseph` (requires C++ compiler or Docker for swisseph ephemeris calculations)
- **Python**: 3.11.x in the active Windows runtime

### Important: Ephemeris Data Files
From PyJHora version 3.6.6 onwards, the installation wheel/tar file does **NOT** contain the ephemeris data files. You must:
1. Download from: `https://github.com/naturalstupid/pyjhora/src/jhora/data/ephe` folder
2. Copy all files to the package installation directory: `jhora/data/ephe/`
3. In Docker, these must be included in the image or mounted as a volume

## Build/Lint/Test Commands

### Initialize Project
```bash
# Create virtual environment
uv venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate  # Windows

# Install dependencies
pip install PyJHora
pip install fastmcp[dev]

# OR with uv
uv pip install PyJHora fastmcp[dev]
```

### Run the MCP Server
```bash
# Development mode (stdio transport)
fastmcp run src/pyjhora_mcp/server.py --transport stdio

# Development mode (HTTP transport for debugging)
fastmcp run src/pyjhora_mcp/server.py --transport http --port 8000

# With uv directly
uv run fastmcp run src/pyjhora_mcp/server.py
```

### Run Tests
```bash
# Run all tests
uv run pytest tests/ -v

# Run a single test file
uv run pytest tests/test_panchanga.py -v

# Run a single test function
uv run pytest tests/test_panchanga.py::test_tithi_calculation -v

# Run with coverage
uv run pytest tests/ --cov=src/pyjhora_mcp --cov-report=html
```

### Lint and Format
```bash
# Format code
uv run ruff format src/ tests/# Check linting
uv run ruff check src/ tests/

# Type checking
uv run mypy src/pyjhora_mcp/
```

### Docker Commands
```bash
# Build Docker image
docker build -t pyjhora-mcp:latest .

# Run in Docker (stdio)
docker run --rm -i pyjhora-mcp:latest

# Run in Docker (HTTP)
docker run --rm -p8000:8000 pyjhora-mcp:latest --transport http

# Interactive shell for debugging
docker run -it --rm pyjhora-mcp:latest /bin/bash
```

## Code Style Guidelines

### Imports
```python
# Standard library first
from __future__ import annotations
from datetime import datetime
from typing import Any, Optional

# Third-party imports (alphabetical)
import swisseph as swe
from fastmcp import FastMCP

# Local imports last
from jhora import const, utils
from jhora.panchanga import drik
from jhora.horoscope.chart import charts
```

### Type Annotations
- Use modern Python type hints (`list[dict]` not `List[Dict]`)
- Prefer `Optional[T]` or `T | None` for optional parameters
- Use TypedDict for complex return structures
- Document return types with docstrings

```python
def calculate_planet_positions(
    jd: float,
    place: tuple[str, float, float, float],
    planet_ids: list[int] | None = None
) -> list[tuple[int, tuple[int, float]]]:
    """Calculate planetary positions for given Julian day and place."""
    ...
```

### Function Naming Conventions
- snake_case for functions and variables
- PascalCase for classes and TypedDicts
- UPPER_SNAKE_CASE for constants
- Leading underscore for internal helpers (`_internal_func`)

### Error Handling
Tools do not raise calculation errors to the MCP caller. They preserve partial
results and return an error object with the same shape everywhere:

```python
{
    "code": "CALCULATION_ERROR",
    "type": "ValueError",
    "message": "human-readable detail",
    "recoverable": True,
}
```

Use `error_payload()` from `utils/converters.py`. Keep legacy field names such
as `error` and `planets_error` when they are part of a tool's public result;
only the value inside those fields uses the structured error shape.

### PyJHora Integration Patterns
```python
# Pattern 1: Initialize place tuple
Place = namedtuple('Place', ['place', 'latitude', 'longitude', 'timezone'])
place = Place("Chennai,IN", 13.0878, 80.2785, +5.5)

# Pattern 2: Convert date/time to Julian day
from jhora import utils
jd = utils.julian_day_number(Date(2024, 1, 15), (10, 30, 0))

# Pattern 3: Set ayanamsa mode before calculations
from jhora.panchanga import drik
drik.set_ayanamsa_mode('LAHIRI')  # or 'TRUE_PUSHYA', 'KP', etc.

# Pattern 4: Get planet positions
from jhora.horoscope.chart import charts
planet_positions = charts.rasi_chart(jd, place)
```

## MCP Tool Structure

### Tool Definition Template
```python
from fastmcp import FastMCP
from pydantic import BaseModel, Field

mcp = FastMCP(name="PyJHora MCP Server")

class PlaceInput(BaseModel):
    """Input model for place/location"""
    name: str = Field(description="Place name with country code, e.g., 'Chennai,IN'")
    latitude: float = Field(description="Latitude in decimal degrees")
    longitude: float = Field(description="Longitude in decimal degrees")
    timezone: float = Field(description="Timezone offset from UTC, e.g., +5.5 for IST")

class DateTimeInput(BaseModel):
    """Input model for date/time"""
    year: int
    month: int
    day: int
    hour: int = 0
    minute: int = 0
    second: int = 0

@mcp.tool
def get_panchanga(place: PlaceInput, date_time: DateTimeInput) -> dict:
    """Calculate panchanga elements (tithi, nakshatra, yoga, karana, vaara).
    Args:
        place: Location information with coordinates and timezone
        date_time: Date and time for calculation
    Returns:
        Dictionary with panchanga details
    """
    # Implementation
    ...
```

### Key Tool Categories to Implement
1. **Panchanga Tools**:
   - `get_panchanga` - Basic panchanga elements
   - `get_sunrise_sunset` - Sun/moon rise/set times
   - `get_muhurtha` - Auspicious timings

2. **Horoscope Tools**:
   - `get_rasi_chart` - Birth chart (D1)
   - `get_navamsa_chart` - D9 chart
   - `get_divisional_chart` - Any varga chart

3. **Dasha Tools**:
   - `get_vimsottari_dasha` - Vimsottari dasha periods
   - `get_narayana_dasha` - Narayana dasha

4. **Compatibility Tools**:
   - `get_compatibility` - Marriage compatibility

5. **Yoga/Dosha Tools**:
   - `get_yogas` - Planetary yogas
   - `get_doshas` - Planetary doshas

## Docker Configuration

### Dockerfile Template
```dockerfile
FROM python:3.11-slim

# Install build dependencies for pyswisseph
RUN apt-get update && apt-get install -y \
    build-essential \
    swig \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app

# Install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Install PyJHora from PyPI
RUN pip install PyJHora

# Copy ephemeris data files (download from GitHub first)
# https://github.com/naturalstupid/pyjhora/src/jhora/data/ephe
COPY ephe/ /usr/local/lib/python3.11/site-packages/jhora/data/ephe/

# Copy MCP server code
COPY src/ /app/src

# Run the MCP server
CMD ["fastmcp", "run", "src/pyjhora_mcp/server.py"]
```

### Docker Compose for Development
```yaml
version: '3.8'
services:
  pyjhora-mcp:
    build: .
    ports:
      - "8000:8000"
    environment:
      - PYTHONUNBUFFERED=1
    volumes:
      # Mount ephemeris data files
      - ./ephe:/usr/local/lib/python3.11/site-packages/jhora/data/ephe:ro
    command: fastmcp run src/pyjhora_mcp/server.py --transport http --port 8000
```

### Ephemeris Data Setup
Before building Docker image:
```bash
# Download ephemeris data files
git clone --depth 1 https://github.com/naturalstupid/pyjhora.git /tmp/pyjhora

# Copy ephemeris files to project
cp -r /tmp/pyjhora/src/jhora/data/ephe ./ephe/

# Clean up
rm -rf /tmp/pyjhora
```

## Important Notes

### PyJHora Dependencies
PyJHora has two types of dependencies:

**Core (required for MCP server)**:
- `pyswisseph==2.10.3.2` - Swiss Ephemeris calculations
- `numpy==2.1.1` - Numerical operations
- `pytz==2024.1` - Timezone handling
- `timezonefinder==6.5.2` - Timezone lookup
- `geopy==2.4.1` - Geocoding (optional for place lookup)
- `geocoder==1.38.1` - Geocoding (optional)
- `Requests==2.32.3` - HTTP requests

**UI (NOT needed for MCP server)**:
- `PyQt6==6.7.1` - GUI framework
- `pyqtgraph==0.13.7` - Plotting
- `img2pdf==0.5.1` - PDF generation

### Swiss Ephemeris Data Files
- PyJHora requires ephemeris data files from `jhora/data/ephe/`
- These must be included in Docker image or mounted as volume
- Default path is set in `const._EPHIMERIDE_DATA_PATH`

### Ayanamsa Modes
- Default in the active MCP contract: `LAHIRI`
- Common alternatives: `LAHIRI`, `KP`, `RAMAN`
- Set before calculations: `drik.set_ayanamsa_mode('LAHIRI')`

### Output Schemas
- Registered tools annotate their return values with `typing_extensions.TypedDict` models from `models/schemas.py`.
- FastMCP uses these annotations to publish detailed `outputSchema` objects.
- Implementations may still return ordinary dictionaries so direct integration tests remain simple.

### Test Data
- PyJHora uses `const._DEFAULT_AYANAMSA_MODE='LAHIRI'` for tests
- Reference test module: `jhora.tests.pvr_tests` (~6800 tests)

### Performance Considerations
- Swiss ephemeris calculations are CPU-intensive
- Consider caching results for repeated calculations
- Use background tasks for batch processing

## File Structure

```
pyjhora-mcp/
├── src/pyjhora_mcp/
│   ├── __init__.py
│   ├── server.py          # FastMCP server entry point
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── panchanga.py   # Panchanga-related tools
│   │   ├── horoscope.py   # Chart calculations
│   │   ├── dasha.py       # Dasha calculations
│   │   └── compatibility.py
│   ├── models/
│   │   ├── __init__.py
│   │   └── schemas.py     # Pydantic models
│   └── utils/
│       ├── __init__.py
│       └── converters.py  # Date/place conversions
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   ├── test_panchanga.py
│   └── test_horoscope.py
├── pyproject.toml
├── requirements.txt
├── Dockerfile
├── docker-compose.yml└── AGENTS.md
```

## References

- PyJHora GitHub: https://github.com/naturalstupid/pyjhora
- FastMCP Docs: https://gofastmcp.com/
- Swiss Ephemeris: https://www.astro.com/swisseph/
- MCP Specification: https://modelcontextprotocol.io/
