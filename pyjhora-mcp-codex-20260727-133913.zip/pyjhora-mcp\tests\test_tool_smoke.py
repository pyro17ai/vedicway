"""Smoke tests for every advertised MCP tool."""

from __future__ import annotations

from typing import Any

from pyjhora_mcp.models.schemas import (
    AyanamsaMode,
    BirthDataInput,
    CompatibilityInput,
    DateTimeInput,
    PlaceInput,
)
from pyjhora_mcp.tools.compatibility import get_compatibility
from pyjhora_mcp.tools.dasha import (
    get_ashtottari_dasha,
    get_narayana_dasha,
    get_vimsottari_dasha,
    get_yogini_dasha,
)
from pyjhora_mcp.tools.horoscope import (
    get_ashtakavarga,
    get_bhava_chart,
    get_divisional_chart,
    get_rasi_chart,
    get_special_lagnas,
)
from pyjhora_mcp.tools.panchanga import (
    get_festivals,
    get_muhurtha,
    get_panchanga,
    get_planet_positions,
    get_rahu_kala,
    get_sunrise_sunset,
)
from pyjhora_mcp.tools.strength import (
    get_bhava_bala,
    get_shadbala,
    get_vimsopaka_bala,
)
from pyjhora_mcp.tools.yoga import get_doshas, get_raja_yogas, get_yogas


def _find_error_paths(value: Any, path: str = "") -> list[str]:
    if isinstance(value, dict):
        errors = []
        if "error" in value:
            errors.append(path or "<root>")
        for key, child in value.items():
            child_path = f"{path}.{key}" if path else str(key)
            if key.endswith("_error"):
                errors.append(child_path)
            errors.extend(_find_error_paths(child, child_path))
        return errors
    if isinstance(value, list):
        errors = []
        for index, child in enumerate(value):
            errors.extend(_find_error_paths(child, f"{path}[{index}]"))
        return errors
    return []


def test_all_advertised_tools_return_without_error_fields() -> None:
    chennai = PlaceInput(
        name="Chennai,IN",
        latitude=13.0878,
        longitude=80.2785,
        timezone=5.5,
    )
    delhi = PlaceInput(
        name="New Delhi,IN",
        latitude=28.6139,
        longitude=77.2090,
        timezone=5.5,
    )
    date_time = DateTimeInput(
        year=2024,
        month=1,
        day=15,
        hour=10,
        minute=30,
        second=0,
    )
    birth_data = BirthDataInput(
        place=chennai,
        date_time=date_time,
        ayanamsa=AyanamsaMode.LAHIRI,
    )
    compatibility_input = CompatibilityInput(
        boy_birth=BirthDataInput(
            place=chennai,
            date_time=DateTimeInput(year=1990, month=6, day=15, hour=10),
            ayanamsa=AyanamsaMode.LAHIRI,
        ),
        girl_birth=BirthDataInput(
            place=delhi,
            date_time=DateTimeInput(year=1992, month=3, day=20, hour=14, minute=30),
            ayanamsa=AyanamsaMode.LAHIRI,
        ),
    )

    tool_calls = {
        "get_panchanga": lambda: get_panchanga(birth_data),
        "get_sunrise_sunset": lambda: get_sunrise_sunset(chennai, date_time),
        "get_rahu_kala": lambda: get_rahu_kala(chennai, date_time),
        "get_muhurtha": lambda: get_muhurtha(chennai, date_time),
        "get_planet_positions": lambda: get_planet_positions(birth_data),
        "get_festivals": lambda: get_festivals(chennai, date_time),
        "get_rasi_chart": lambda: get_rasi_chart(birth_data),
        "get_divisional_chart": lambda: get_divisional_chart(birth_data, 9),
        "get_special_lagnas": lambda: get_special_lagnas(birth_data),
        "get_ashtakavarga": lambda: get_ashtakavarga(birth_data),
        "get_bhava_chart": lambda: get_bhava_chart(birth_data),
        "get_vimsottari_dasha": lambda: get_vimsottari_dasha(birth_data),
        "get_yogini_dasha": lambda: get_yogini_dasha(birth_data),
        "get_ashtottari_dasha": lambda: get_ashtottari_dasha(birth_data),
        "get_narayana_dasha": lambda: get_narayana_dasha(birth_data),
        "get_compatibility": lambda: get_compatibility(compatibility_input),
        "get_yogas": lambda: get_yogas(birth_data),
        "get_doshas": lambda: get_doshas(birth_data),
        "get_raja_yogas": lambda: get_raja_yogas(birth_data),
        "get_shadbala": lambda: get_shadbala(birth_data),
        "get_bhava_bala": lambda: get_bhava_bala(birth_data),
        "get_vimsopaka_bala": lambda: get_vimsopaka_bala(birth_data),
    }

    failures: dict[str, list[str]] = {}
    for name, call_tool in tool_calls.items():
        result = call_tool()
        error_paths = _find_error_paths(result)
        if error_paths:
            failures[name] = error_paths

    assert failures == {}
