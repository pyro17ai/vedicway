# tests/ — Test Suite

**Generated:** 2026-03-16
**Commit:** 09486f3

## OVERVIEW

Integration tests for PyJHora MCP tools. Uses pytest with shared fixtures. Tests call actual PyJHora library (no mocking).

## STRUCTURE

```
tests/
├── __init__.py
├── conftest.py          # Shared pytest fixtures
├── test_panchanga.py    # Panchanga tools (6 test classes)
├── test_horoscope.py    # Horoscope tools (5 test classes)
├── test_dasha.py        # Dasha tools (3 test classes)
└── test_compatibility.py # Compatibility tool (1 test class)
```

## WHERE TO LOOK

| Task | File |
|------|------|
| Add test for new tool | Create `test_<tool>.py` |
| Add new fixture | `conftest.py` |
| Debug failing test | Check fixture data validity |
| Run specific test | `pytest tests/test_panchanga.py::TestGetPanchanga::test_name -v` |

## FIXTURES (conftest.py)

### Location Fixtures
| Fixture | Description |
|---------|-------------|
| `chennai_place` | Chennai, IN (13.0878, 80.2785, +5.5) |
| `new_delhi_place` | New Delhi, IN (28.6139, 77.2090, +5.5) |

### Date Fixtures
| Fixture | Description |
|---------|-------------|
| `sample_date` | 2024-01-15 10:30:00 IST |
| `pvr_birth_date` | 1970-01-01 08:30:00 IST |

### Birth Data Fixtures
| Fixture | Composition |
|---------|-------------|
| `sample_birth_data` | Chennai + sample_date + LAHIRI |
| `pvr_birth_data` | Chennai + pvr_birth_date + LAHIRI |
| `compatibility_input` | Boy (Chennai, 1990) + Girl (Delhi, 1992) |

## CONVENTIONS

### Test Class Pattern
```python
class TestGetToolName:
    def test_returns_expected_structure(self, sample_birth_data):
        result = get_tool_name(sample_birth_data)
        assert "expected_key" in result

    def test_field_has_valid_range(self, sample_birth_data):
        result = get_tool_name(sample_birth_data)
        assert 0 <= result["field"] <= 11
```

### Naming Conventions
- **Classes**: `TestGet<ToolName>` (PascalCase)
- **Functions**: `test_<behavior>` (snake_case)
- **Patterns**:
  - `test_returns_<description>` — Structure validation
  - `test_<field>_has_required_fields` — Field presence
  - `test_<field>_valid_range` — Value bounds

### Error Handling in Tests
```python
# Assert no error in result
assert "error" not in field, f"Error: {field.get('error')}"

# Or check for expected error
assert "error" in result  # When testing error conditions
```

## TEST ORGANIZATION

- **One class per tool function**
- **Integration tests** — No mocking, calls real PyJHora
- **Editorial assertions** — Docstrings explain known facts (e.g., "Jan 15, 2024 is Monday")
- **Graceful handling** — Tests account for optional fields returning "N/A"

## RUNNING TESTS

```bash
# All tests
uv run pytest tests/ -v

# Single file
uv run pytest tests/test_panchanga.py -v

# Single test function
uv run pytest tests/test_panchanga.py::TestGetPanchanga::test_returns_all_five_limbs -v

# With coverage
uv run pytest tests/ --cov=src/pyjhora_mcp --cov-report=term-missing
```

## ANTI-PATTERNS (THIS PROJECT)

- **NO** `unittest.mock` — Tests use real PyJHora calculations
- **NO** `pytest.skip` — All tests should pass with ephemeris data
- **NO** hardcoded dates — Use fixtures for consistency
- **NO** `print()` in tests — Use assertions only

## PREREQUISITES

Tests require ephemeris data files (.se1) installed in PyJHora package directory:
```
<path-to-venv>/Lib/site-packages/jhora/data/ephe/*.se1
```

Without these, all tests will fail with Swiss Ephemeris errors.