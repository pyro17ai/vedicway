# PyJHora MCP Server

A complete [Model Context Protocol (MCP)](https://modelcontextprotocol.io/) server that exposes [PyJHora](https://github.com/naturalstupid/pyjhora) Vedic astrology calculations as typed, discoverable LLM tools via the [FastMCP](https://gofastmcp.com/) framework.

## Features — 22 MCP Tools

| Category | Tools |
|----------|-------|
| 🗓️ **Panchanga** | `get_panchanga`, `get_sunrise_sunset`, `get_rahu_kala`, `get_muhurtha`, `get_planet_positions`, `get_festivals` |
| 🌟 **Horoscope** | `get_rasi_chart`, `get_divisional_chart`, `get_special_lagnas`, `get_ashtakavarga`, `get_bhava_chart` |
| 📅 **Dasha** | `get_vimsottari_dasha`, `get_yogini_dasha`, `get_ashtottari_dasha`, `get_narayana_dasha` |
| 💑 **Compatibility** | `get_compatibility` |
| 🔯 **Yoga & Dosha** | `get_yogas`, `get_doshas`, `get_raja_yogas` |
| 💪 **Strength** | `get_shadbala`, `get_bhava_bala`, `get_vimsopaka_bala` |

## Prerequisites

- Python 3.11
- [uv](https://github.com/astral-sh/uv) package manager
- **Ephemeris data files** (see below — critical!)

## ⚠️ Ephemeris Data Setup (Required)

PyJHora v3.6.6+ does **NOT** bundle `.se1` Swiss Ephemeris data files in the PyPI package. Without them, all calculations fail.

**Download and install:**

```bash
# 1. Clone PyJHora temporarily to get the ephe files
git clone --depth 1 https://github.com/naturalstupid/pyjhora.git /tmp/pyjhora

# 2. Find where PyJHora was installed in your venv
python -c "import jhora; import os; print(os.path.dirname(jhora.__file__))"
# Example output: C:\Users\admin\Desktop\projects\pyjhora-mcp\.venv\Lib\site-packages\jhora

# 3. Copy ephemeris files into the package (Windows example)
xcopy /E /I /Y /tmp/pyjhora/src/jhora/data/ephe ".venv\Lib\site-packages\jhora\data\ephe"

# 4. Clean up
rm -rf /tmp/pyjhora
```

Alternatively, download only the `ephe/` folder directly from [GitHub](https://github.com/naturalstupid/pyjhora/tree/main/src/jhora/data/ephe).

## Installation

```bash
# Clone this repo and enter the project
git clone <this-repo>
cd pyjhora-mcp

# Create virtual environment
uv venv --python 3.11
.venv\Scripts\activate  # Windows
# source .venv/bin/activate  # Linux/macOS

# Install the package and all dependencies
uv pip install -e ".[dev]"
```

> **Windows Note**: `pyswisseph` requires a C++ compiler. Install [Visual Studio Build Tools](https://visualstudio.microsoft.com/downloads/#build-tools-for-visual-studio-2022) if you encounter compilation errors.

## Running the Server

```bash
# stdio transport (default — for Claude Desktop, Cursor, etc.)
fastmcp run src/pyjhora_mcp/server.py

# HTTP transport (for debugging / browser testing)
fastmcp run src/pyjhora_mcp/server.py --transport http --port 8000

# Or using the installed script
pyjhora-mcp
```

## VPS Service Install (systemd + Caddy)

This repository includes a self-managed installer script that can install and uninstall:

- Python runtime dependencies
- systemd service (`pyjhora-mcp.service`)
- Caddy with reverse proxy for `pyjhora-mcp.lairfrost.dev`

Run on your VPS from the project root:

```bash
chmod +x deploy-service.sh
sudo bash ./deploy-service.sh install
```

Useful commands:

```bash
sudo bash ./deploy-service.sh status
sudo bash ./deploy-service.sh logs
sudo bash ./deploy-service.sh uninstall
```

Optional overrides:

```bash
sudo DOMAIN=pyjhora-mcp.lairfrost.dev APP_PORT=8000 bash ./deploy-service.sh install
```

The Caddy snippet template is also included at `deploy/pyjhora-mcp.Caddyfile`.

### Auth on VPS (Render parity)

Your existing auth flow still works on VPS:

- Client sends `Authorization: Bearer <token>`
- Server validates against `API_KEY` from environment
- Caddy reverse proxy forwards `Authorization` header by default

No Python dotenv package is required for this deployment.

Set API key in the managed env file created by installer:

```bash
sudo nano /etc/pyjhora-mcp/pyjhora-mcp.env
# set API_KEY=your_real_secret

sudo systemctl restart pyjhora-mcp.service
```

## Claude Desktop Integration

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "pyjhora": {
      "command": "uv",
      "args": [
        "run",
        "--project",
        "C:/path/to/pyjhora-mcp",
        "fastmcp",
        "run",
        "src/pyjhora_mcp/server.py"
      ]
    }
  }
}
```

## Running Tests

```bash
# Run all tests (requires ephemeris files)
uv run pytest tests/ -v

# With coverage
uv run pytest tests/ --cov=src/pyjhora_mcp --cov-report=term-missing
```

## Docker

```bash
# 1. Download ephe files first
mkdir ephe
# Copy .se1 files from PyJHora GitHub into ./ephe/

# 2. Build image
docker build -t pyjhora-mcp:latest .

# 3. Run (HTTP mode)
docker run --rm -p 8000:8000 pyjhora-mcp:latest fastmcp run src/pyjhora_mcp/server.py --transport http --port 8000

# 4. Or use docker-compose
docker-compose up
```

## Tool Examples

### Get Daily Panchanga
```json
{
  "tool": "get_panchanga",
  "arguments": {
    "birth_data": {
      "place": {"name": "Chennai,IN", "latitude": 13.0878, "longitude": 80.2785, "timezone": 5.5},
      "date_time": {"year": 2024, "month": 1, "day": 15, "hour": 10, "minute": 30, "second": 0},
      "ayanamsa": "LAHIRI"
    }
  }
}
```

### Get Birth Chart (Rasi D1)
```json
{
  "tool": "get_rasi_chart",
  "arguments": {
    "birth_data": {
      "place": {"name": "Mumbai,IN", "latitude": 19.076, "longitude": 72.8777, "timezone": 5.5},
      "date_time": {"year": 1990, "month": 6, "day": 15, "hour": 8, "minute": 0, "second": 0},
      "ayanamsa": "LAHIRI"
    }
  }
}
```

### Get Vimsottari Dasha
```json
{
  "tool": "get_vimsottari_dasha",
  "arguments": {
    "birth_data": { "...": "..." },
    "include_antara": true,
    "include_pratyantara": false
  }
}
```

## Ayanamsa Modes

| Mode | Description |
|------|-------------|
| `LAHIRI` | Most widely used, standard Indian government ayanamsa |
| `TRUE_PUSHYA` | Default in JHora v4.7.0, matches Jagannatha Hora software |
| `KP` | Krishnamurti Paddhati system |
| `RAMAN` | BV Raman's ayanamsa |

## Project Structure

```
pyjhora-mcp/
├── src/pyjhora_mcp/
│   ├── server.py          # FastMCP server entry point
│   ├── models/schemas.py  # Pydantic input/output models
│   ├── utils/converters.py # Date/place/name helpers
│   └── tools/
│       ├── panchanga.py   # 6 panchanga tools
│       ├── horoscope.py   # 5 chart tools
│       ├── dasha.py       # 4 dasha tools
│       ├── compatibility.py # 1 compatibility tool
│       ├── yoga.py        # 3 yoga/dosha tools
│       └── strength.py    # 3 strength tools
├── tests/
│   ├── conftest.py
│   ├── test_panchanga.py
│   ├── test_horoscope.py
│   ├── test_dasha.py
│   └── test_compatibility.py
├── Dockerfile
├── docker-compose.yml
└── pyproject.toml
```

## References

- [PyJHora GitHub](https://github.com/naturalstupid/pyjhora)
- [FastMCP Documentation](https://gofastmcp.com/)
- [Swiss Ephemeris](https://www.astro.com/swisseph/)
- [MCP Specification](https://modelcontextprotocol.io/)
