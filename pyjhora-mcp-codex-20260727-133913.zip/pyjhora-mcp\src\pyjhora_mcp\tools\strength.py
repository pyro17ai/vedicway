"""Planetary strength (Bala) MCP tools.

Wraps: jhora.horoscope.chart.strength
"""

from __future__ import annotations

from typing import Any

from fastmcp import FastMCP

from pyjhora_mcp.models.schemas import (
    BhavaBalaResult,
    BirthDataInput,
    ShadbalaResult,
    VimsopakaBalaResult,
)
from pyjhora_mcp.utils.converters import (
    error_payload,
    planet_id_to_name,
    set_ayanamsa,
    to_julian_day,
    to_place,
)

mcp = FastMCP(name="Strength Tools")

_SHADBALA_COMPONENTS = [
    "sthana_bala",  # Positional strength
    "kala_bala",  # Temporal strength
    "dig_bala",  # Directional strength
    "cheshta_bala",  # Motional strength
    "naisargika_bala",  # Natural strength
    "drik_bala",  # Aspectual strength
]


# ---------------------------------------------------------------------------
# get_shadbala
# ---------------------------------------------------------------------------


@mcp.tool
def get_shadbala(birth_data: BirthDataInput) -> ShadbalaResult:
    """Calculate Shadbala (six-fold strength) for all planets in a birth chart.

    Shadbala measures planetary strength from 6 different perspectives:
    1. **Sthana Bala** — Positional/digit strength (exaltation, own sign, etc.)
    2. **Dig Bala** — Directional strength (best direction for each planet)
    3. **Kala Bala** — Temporal strength (time of day, paksha, hora, etc.)
    4. **Cheshta Bala** — Motional strength (retrograde planets are stronger)
    5. **Naisargika Bala** — Natural/inherent strength (Sun > Moon > Venus > ...)
    6. **Drik Bala** — Aspectual strength (benefic/malefic aspects received)

    Minimum required Shadbala values (Rupas):
    - Sun: 6.5, Moon: 6.0, Mars: 5.0, Mercury: 7.0
    - Jupiter: 6.5, Venus: 5.5, Saturn: 5.0

    Args:
        birth_data: Birth location, date, time, and ayanamsa.

    Returns:
        Dictionary with Shadbala components and total Shadbala Rupas for each planet.
    """
    from jhora.horoscope.chart import strength

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {"shadbala": {}}

    # Minimum required shadbala (rupas) for each planet
    min_required = {0: 6.5, 1: 6.0, 2: 5.0, 3: 7.0, 4: 6.5, 5: 5.5, 6: 5.0}

    try:
        shadbala_result = strength.shad_bala(jd, place)

        if shadbala_result:
            for pid in range(7):  # Sun to Saturn (classic 7 planets for Shadbala)
                pname = planet_id_to_name(pid)
                planet_strength: dict[str, Any] = {}

                if isinstance(shadbala_result, (list, tuple)) and pid < len(shadbala_result):
                    for i, comp in enumerate(_SHADBALA_COMPONENTS):
                        if i < len(shadbala_result) and pid < len(shadbala_result[i]):
                            planet_strength[comp] = round(float(shadbala_result[i][pid]), 4)
                    if len(shadbala_result) > 6:
                        planet_strength["total_shastiamsas"] = round(
                            float(shadbala_result[6][pid]), 4
                        )
                    if len(shadbala_result) > 7:
                        planet_strength["total_rupas"] = round(float(shadbala_result[7][pid]), 4)
                    if len(shadbala_result) > 8:
                        planet_strength["strength_ratio"] = round(float(shadbala_result[8][pid]), 4)

                # Add minimum required and pass/fail
                if pid in min_required and "total_rupas" in planet_strength:
                    planet_strength["minimum_required"] = min_required[pid]
                    planet_strength["sufficient"] = (
                        planet_strength["total_rupas"] >= min_required[pid]
                    )

                result["shadbala"][pname] = planet_strength

    except Exception as e:
        result["error"] = error_payload(e)

    return result


# ---------------------------------------------------------------------------
# get_bhava_bala
# ---------------------------------------------------------------------------


@mcp.tool
def get_bhava_bala(birth_data: BirthDataInput) -> BhavaBalaResult:
    """Calculate Bhava Bala (house strength) for all 12 houses in a birth chart.

    Bhava Bala measures the strength of each house from three sources:
    1. **Bhavadhipati Bala**: Strength of the house lord
    2. **Bhava Dig Bala**: Directional strength of the house
    3. **Bhava Drishti Bala**: Aspectual strength on the house

    Stronger houses generally produce better results in their significations.

    Args:
        birth_data: Birth location, date, time, and ayanamsa.

    Returns:
        Dictionary with strength components for each of the 12 houses.
    """
    from jhora.horoscope.chart import strength

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {"bhava_bala": {}}

    try:
        bala_result = strength.bhava_bala(jd, place)

        if bala_result:
            for i in range(12):
                house_name = f"House {i + 1}"
                result["bhava_bala"][house_name] = {
                    "total_shastiamsas": round(float(bala_result[0][i]), 4),
                    "total_rupas": round(float(bala_result[1][i]), 4),
                    "strength_ratio": round(float(bala_result[2][i]), 4),
                }

    except Exception as e:
        result["error"] = error_payload(e)

    return result


# ---------------------------------------------------------------------------
# get_vimsopaka_bala
# ---------------------------------------------------------------------------


@mcp.tool
def get_vimsopaka_bala(birth_data: BirthDataInput) -> VimsopakaBalaResult:
    """Calculate Vimsopaka Bala (20-point divisional strength) for all planets.

    Vimsopaka Bala measures how well a planet is placed across multiple
    divisional charts simultaneously. The more harmonious positions across
    vargas, the stronger the planet.

    Variants supported:
    - **Dasa Varga**: D1, D2, D3, D7, D9, D10, D12, D16, D20, D24 (max 20 pts)
    - **Shad Varga**: D1, D2, D3, D9, D12, D30 (max 20 pts)
    - **Sapta Varga**: D1, D2, D3, D7, D9, D12, D30 (max 20 pts)
    - **Shodasa Varga**: D1…D60 (max 20 pts)

    Args:
        birth_data: Birth location, date, time, and ayanamsa.

    Returns:
        Dictionary with Vimsopaka Bala scores per planet for each varga group.
    """
    from jhora.horoscope.chart import charts

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {"vimsopaka_bala": {}}

    varga_methods = {
        "dasa_varga": charts.vimsopaka_dhasavarga_of_planets,
        "shad_varga": charts.vimsopaka_shadvarga_of_planets,
        "sapta_varga": charts.vimsopaka_sapthavarga_of_planets,
        "shodasa_varga": charts.vimsopaka_shodhasavarga_of_planets,
    }

    try:
        for method_name, method_fn in varga_methods.items():
            method_result: dict[str, Any] = {}
            try:
                vb = method_fn(jd, place)
                if vb:
                    for pid in range(9):  # Sun to Ketu
                        pname = planet_id_to_name(pid)
                        if isinstance(vb, dict) and pid in vb:
                            amsa_count, vargas, score = vb[pid]
                            method_result[pname] = {
                                "score": round(float(score), 4),
                                "varga_count": int(amsa_count),
                                "vargas": str(vargas),
                            }
            except Exception as e:
                method_result["error"] = error_payload(e)
            result["vimsopaka_bala"][method_name] = method_result

    except Exception as e:
        result["error"] = error_payload(e)

    return result
