"""Tests for compatibility tools."""

from pyjhora_mcp.tools.compatibility import get_compatibility


class TestGetCompatibility:
    """Tests for the get_compatibility tool."""

    def test_returns_result(self, compatibility_input):
        result = get_compatibility(compatibility_input)
        assert isinstance(result, dict)

    def test_has_method_label(self, compatibility_input):
        result = get_compatibility(compatibility_input)
        assert "method" in result

    def test_has_boy_and_girl_info(self, compatibility_input):
        result = get_compatibility(compatibility_input)
        assert "boy" in result
        assert "girl" in result

    def test_total_score_in_range(self, compatibility_input):
        result = get_compatibility(compatibility_input)
        score = result.get("total_score")
        if score is not None and isinstance(score, (int, float)):
            assert 0 <= score <= 36, f"Ashta Koota score {score} should be between 0 and 36"

    def test_has_nakshatra_info(self, compatibility_input):
        result = get_compatibility(compatibility_input)
        # Supplementary nakshatra info should be present if ephemeris loaded
        boy = result.get("boy", {})
        girl = result.get("girl", {})
        # These may be absent if ephe files not found, so just check structure
        assert isinstance(boy, dict)
        assert isinstance(girl, dict)
