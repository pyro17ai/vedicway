"""Yoga (planetary combinations) and Dosha MCP tools.

Wraps: jhora.horoscope.chart.yoga, jhora.horoscope.chart.dosha,
       jhora.horoscope.chart.raja_yoga
"""

from __future__ import annotations

from typing import Any

from fastmcp import FastMCP

from pyjhora_mcp.models.schemas import BirthDataInput, DoshasResult, RajaYogasResult, YogasResult
from pyjhora_mcp.utils.converters import (
    error_payload,
    set_ayanamsa,
    to_julian_day,
    to_place,
)

mcp = FastMCP(name="Yoga & Dosha Tools")


# ---------------------------------------------------------------------------
# get_yogas
# ---------------------------------------------------------------------------


@mcp.tool
def get_yogas(birth_data: BirthDataInput) -> YogasResult:
    """Identify active planetary Yogas in a Vedic birth chart.

    PyJHora supports 284+ yogas from classical texts including:
    - **Pancha Mahapurusha Yogas**: Ruchaka, Bhadra, Sasa, Malavya, Hamsa
    - **Dhana Yogas**: Wealth-producing combinations
    - **Raja Yogas**: Combinations for power and authority
    - **Chandra Yogas**: Sunapha, Anapha, Durudhara, Kemadruma
    - **Special Yogas**: Gaja-Kesari, Neecha-Bhanga, Vipareetha Raja Yoga
    - And 270+ more from BV Raman and other classical sources

    Args:
        birth_data: Birth location, date, time, and ayanamsa.

    Returns:
        Dictionary with list of active yogas and their descriptions.
    """
    from jhora.horoscope.chart import yoga

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {"yogas": [], "count": 0, "total_checked": 0}

    try:
        yoga_results, count, total_checked = yoga.get_yoga_details(jd, place)

        if yoga_results:
            yoga_list = []
            if isinstance(yoga_results, dict):
                for yoga_name, details in yoga_results.items():
                    entry: dict[str, Any] = {"id": yoga_name}
                    if isinstance(details, (list, tuple)) and len(details) >= 4:
                        entry.update(
                            {
                                "chart": details[0],
                                "name": details[1],
                                "condition": details[2],
                                "effect": details[3],
                            }
                        )
                    else:
                        entry["details"] = details
                    yoga_list.append(entry)

            result["yogas"] = yoga_list
        result["count"] = int(count)
        result["total_checked"] = int(total_checked)

    except Exception as e:
        result["error"] = error_payload(e)

    return result


# ---------------------------------------------------------------------------
# get_doshas
# ---------------------------------------------------------------------------


@mcp.tool
def get_doshas(birth_data: BirthDataInput) -> DoshasResult:
    """Check for planetary Doshas (afflictions) in a Vedic birth chart.

    The following 8 doshas are checked:
    - **Kala Sarpa Dosha**: All planets between Rahu and Ketu
    - **Manglik / Chevvai Dosha**: Mars in 1st, 4th, 7th, 8th, or 12th house
    - **Pitru Dosha**: Affliction indicating ancestral karma
    - **Guru Chandala Dosha**: Jupiter conjunct or aspected by Rahu
    - **Ganda Moola Dosha**: Birth in certain nakshatras at junctions
    - **Kalathra Dosha**: Affliction to marriage house (7th)
    - **Ghata Dosha**: Malefic influence on a specific house
    - **Shrapit Dosha**: Saturn-Rahu conjunction or mutual aspect

    Args:
        birth_data: Birth location, date, time, and ayanamsa.

    Returns:
        Dictionary with dosha name, presence (True/False), and details.
    """
    from jhora.horoscope.chart import dosha

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {"doshas": {}}

    try:
        dosha_details = dosha.get_dosha_details(jd, place)
        for dosha_name, description in dosha_details.items():
            text = str(description)
            result["doshas"][dosha_name] = {
                "present": "there is no" not in text.lower(),
                "description": text,
            }

    except Exception as e:
        result["error"] = error_payload(e)

    return result


# ---------------------------------------------------------------------------
# get_raja_yogas
# ---------------------------------------------------------------------------


@mcp.tool
def get_raja_yogas(birth_data: BirthDataInput) -> RajaYogasResult:
    """Identify Raja Yogas (combinations for power and success) in a birth chart.

    Checks for:
    - **Dharma-Karmadhipati Raja Yoga**: 9th and 10th lords in conjunction/mutual aspect
    - **Vipareetha Raja Yoga**: Lords of dusthanas (6th, 8th, 12th) in each other's houses
    - **Neecha Bhanga Raja Yoga**: Cancellation of debilitation — a powerful yoga

    Args:
        birth_data: Birth location, date, time, and ayanamsa.

    Returns:
        Dictionary with each raja yoga type and whether it is present.
    """
    from jhora.horoscope.chart import raja_yoga

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {"raja_yogas": [], "count": 0, "total_checked": 0}

    try:
        yoga_results, count, total_checked = raja_yoga.get_raja_yoga_details(jd, place)
        result["raja_yogas"] = [
            {"id": yoga_name, "details": details} for yoga_name, details in yoga_results.items()
        ]
        result["count"] = int(count)
        result["total_checked"] = int(total_checked)

    except Exception as e:
        result["error"] = error_payload(e)

    return result
