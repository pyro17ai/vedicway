"""Horoscope chart MCP tools.

Wraps: jhora.horoscope.chart.charts, jhora.panchanga.drik
"""

from __future__ import annotations

from typing import Any

from fastmcp import FastMCP

from pyjhora_mcp.models.schemas import (
    AshtakavargaResult,
    BhavaChartResult,
    BirthDataInput,
    DivisionalChartResult,
    RasiChartResult,
    SpecialLagnasResult,
)
from pyjhora_mcp.utils.converters import (
    error_payload,
    nakshatra_id_to_name,
    planet_id_to_name,
    rasi_id_to_name,
    set_ayanamsa,
    to_julian_day,
    to_place,
)

mcp = FastMCP(name="Horoscope Tools")


def _build_planet_entry(pid: int, rasi_idx: int, long_in_rasi: float) -> dict[str, Any]:
    """Build a single planet position dict."""
    total_long = rasi_idx * 30 + long_in_rasi
    nak_idx = int(total_long // (360 / 27)) + 1
    pada = int((total_long % (360 / 27)) // (360 / 27 / 4)) + 1
    return {
        "planet": planet_id_to_name(pid),
        "planet_index": pid,
        "rasi": rasi_id_to_name(rasi_idx),
        "rasi_index": rasi_idx,
        "longitude_in_rasi": round(long_in_rasi, 4),
        "total_longitude": round(total_long, 4),
        "nakshatra": nakshatra_id_to_name(nak_idx),
        "pada": pada,
    }


def _parse_chart_positions(planet_positions: list) -> list[dict[str, Any]]:
    """Parse the PyJHora planet positions list format [(pid, (rasi, long)), ...]."""
    planets = []
    for item in planet_positions:
        try:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                pid = item[0]
                pos = item[1]
                if isinstance(pos, (list, tuple)) and len(pos) >= 2:
                    rasi_idx = int(pos[0])
                    long_in_rasi = float(pos[1])
                    entry = _build_planet_entry(pid, rasi_idx, long_in_rasi)
                    planets.append(entry)
        except Exception:
            continue
    return planets


# ---------------------------------------------------------------------------
# get_rasi_chart
# ---------------------------------------------------------------------------


@mcp.tool
def get_rasi_chart(birth_data: BirthDataInput) -> RasiChartResult:
    """Calculate the Vedic birth chart (Rasi / D1) for given birth data.

    Returns the Ascendant (Lagna) and all 9 classical Vedic planets' positions
    including their Sign (Rasi), degree, Nakshatra, and Pada.

    Args:
        birth_data: Birth location, date, time, and ayanamsa.

    Returns:
        Dictionary with 'ascendant' and 'planets' list.
    """
    from jhora.horoscope.chart import charts
    from jhora.panchanga import drik

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {
        "chart_type": "D1 (Rasi / Birth Chart)",
        "ayanamsa": birth_data.ayanamsa.value,
        "ascendant": {},
        "planets": [],
    }

    # Ascendant
    try:
        asc = drik.ascendant(jd, place)
        if asc:
            asc_rasi = int(asc[0])
            asc_long = float(asc[1])
            result["ascendant"] = {
                "rasi": rasi_id_to_name(asc_rasi),
                "rasi_index": asc_rasi,
                "longitude_in_rasi": round(asc_long, 4),
                "total_longitude": round(asc_rasi * 30 + asc_long, 4),
                "nakshatra": nakshatra_id_to_name(
                    int((asc_rasi * 30 + asc_long) // (360 / 27)) + 1
                ),
            }
    except Exception as e:
        result["ascendant"] = {"error": error_payload(e)}

    # Planet positions
    try:
        planet_positions = charts.rasi_chart(jd, place)
        result["planets"] = _parse_chart_positions(planet_positions)
    except Exception as e:
        result["planets_error"] = error_payload(e)

    return result


# ---------------------------------------------------------------------------
# get_divisional_chart
# ---------------------------------------------------------------------------


@mcp.tool
def get_divisional_chart(
    birth_data: BirthDataInput,
    divisor: int = 9,
) -> DivisionalChartResult:
    """Calculate a Vedic divisional (Varga) chart for given birth data.

    Common divisors:
    - D1 (1) = Rasi/Birth chart
    - D2 (2) = Hora
    - D3 (3) = Drekkana
    - D4 (4) = Chaturthamsa
    - D7 (7) = Saptamsa
    - D9 (9) = Navamsa (default, most important)
    - D10 (10) = Dasamsa
    - D12 (12) = Dwadasamsa
    - D16 (16) = Shodasamsa
    - D60 (60) = Shashtyamsa

    Args:
        birth_data: Birth location, date, time, and ayanamsa.
        divisor: The varga divisor (1–60). Defaults to 9 (Navamsa).

    Returns:
        Dictionary with chart type, ascendant, and planets.
    """
    from jhora.horoscope.chart import charts
    from jhora.panchanga import drik

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {
        "chart_type": f"D{divisor}",
        "divisor": divisor,
        "ayanamsa": birth_data.ayanamsa.value,
        "ascendant": {},
        "planets": [],
    }

    try:
        planet_positions = charts.divisional_chart(jd, place, divisional_chart_factor=divisor)
        result["planets"] = _parse_chart_positions(planet_positions)
    except Exception as e:
        result["planets_error"] = error_payload(e)

    # Ascendant for D1 reference
    try:
        asc = drik.ascendant(jd, place)
        if asc:
            asc_rasi = int(asc[0])
            asc_long = float(asc[1])
            total_long = asc_rasi * 30 + asc_long
            # Compute divisional ascendant
            div_total = (total_long * divisor) % 360
            div_rasi = int(div_total // 30)
            div_long = div_total % 30
            result["ascendant"] = {
                "rasi": rasi_id_to_name(div_rasi),
                "rasi_index": div_rasi,
                "longitude_in_rasi": round(div_long, 4),
            }
    except Exception as e:
        result["ascendant"] = {"error": error_payload(e)}

    return result


# ---------------------------------------------------------------------------
# get_special_lagnas
# ---------------------------------------------------------------------------


@mcp.tool
def get_special_lagnas(birth_data: BirthDataInput) -> SpecialLagnasResult:
    """Calculate special lagnas (ascendants) for Vedic chart interpretation.

    Returns the positions of:
    - Hora Lagna
    - Ghati Lagna
    - Bhava Lagna (Sripathi)
    - Vighati Lagna
    - Pranapada Lagna
    - Indu Lagna
    - Sree Lagna

    Args:
        birth_data: Birth location, date, time, and ayanamsa.

    Returns:
        Dictionary with each special lagna's rasi and degree.
    """
    from jhora.panchanga import drik

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {}

    special_funcs = {
        "hora_lagna": drik.hora_lagna,
        "ghati_lagna": drik.ghati_lagna,
        "vighati_lagna": drik.vighati_lagna,
        "pranapada_lagna": drik.pranapada_lagna,
        "indu_lagna": drik.indu_lagna,
        "sree_lagna": drik.sree_lagna,
    }

    for name, fn in special_funcs.items():
        try:
            val = fn(jd, place)
            if val is not None:
                if isinstance(val, (list, tuple)) and len(val) >= 2:
                    rasi_idx = int(val[0])
                    long_in_rasi = float(val[1])
                else:
                    total = float(val)
                    rasi_idx = int(total // 30)
                    long_in_rasi = total % 30
                result[name] = {
                    "rasi": rasi_id_to_name(rasi_idx),
                    "rasi_index": rasi_idx,
                    "longitude_in_rasi": round(long_in_rasi, 4),
                }
        except Exception as e:
            result[name] = {"error": error_payload(e)}

    return result


# ---------------------------------------------------------------------------
# get_ashtakavarga
# ---------------------------------------------------------------------------


@mcp.tool
def get_ashtakavarga(birth_data: BirthDataInput) -> AshtakavargaResult:
    """Calculate Ashtakavarga (8-fold division strength chart) for birth data.

    Returns the Bhinnashtakavarga (individual planet bindus) and
    Samudaya Ashtakavarga (combined bindus) for each of the 12 houses.

    Bindus (benefic points) range from 0–8 for each planet per house,
    and 0–337 total (sum of all planets) per house.

    Args:
        birth_data: Birth location, date, time, and ayanamsa.

    Returns:
        Dictionary with planet-wise and total Ashtakavarga scores per house.
    """
    from jhora.horoscope.chart import ashtakavarga, charts

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {}

    try:
        from jhora import utils

        planet_positions = charts.rasi_chart(jd, place)
        house_to_planet_list = utils.get_house_planet_list_from_planet_positions(planet_positions)

        # Bhinnashtakavarga
        try:
            bhinna, samudaya, _ = ashtakavarga.get_ashtaka_varga(house_to_planet_list)
            if bhinna:
                result["bhinnashtakavarga"] = {}
                for pid, bindus in enumerate(bhinna):
                    pname = planet_id_to_name(pid)
                    result["bhinnashtakavarga"][pname] = {
                        f"House {i + 1} ({rasi_id_to_name(i)})": b for i, b in enumerate(bindus)
                    }
        except Exception as e:
            result["bhinnashtakavarga_error"] = error_payload(e)

        # Samudaya Ashtakavarga
        try:
            if samudaya:
                result["samudaya_ashtakavarga"] = {
                    f"House {i + 1} ({rasi_id_to_name(i)})": b for i, b in enumerate(samudaya)
                }
        except Exception as e:
            result["samudaya_ashtakavarga_error"] = error_payload(e)

    except Exception as e:
        result["error"] = error_payload(e)

    return result


# ---------------------------------------------------------------------------
# get_bhava_chart
# ---------------------------------------------------------------------------


@mcp.tool
def get_bhava_chart(birth_data: BirthDataInput, method: int = 1) -> BhavaChartResult:
    """Calculate the Bhava (house) chart with Bhava Madhya (cusp) positions.

    Supports multiple Bhava calculation methods:
    - 1: Equal House (default)
    - 2: KP System
    - 3: Sripathi
    - 4: Placidus
    - 5: Koch
    - 6: Porphyrius
    - 7: Regiomontanus
    - 8: Campanus

    Args:
        birth_data: Birth location, date, time, and ayanamsa.
        method: Bhava calculation method (1–8). Defaults to 1 (Equal House).

    Returns:
        Dictionary with bhava madhya positions for all 12 houses.
    """
    from jhora.horoscope.chart import charts

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {"method": method, "bhavas": []}

    try:
        bhava_data = charts.bhava_chart(jd, place, bhava_madhya_method=method)
        if bhava_data:
            for i, bhava in enumerate(bhava_data[:12]):
                if isinstance(bhava, (list, tuple)) and len(bhava) >= 2:
                    rasi_idx = int(bhava[0])
                    boundaries = bhava[1]
                    total = (
                        float(boundaries[1])
                        if isinstance(boundaries, (list, tuple))
                        else float(boundaries)
                    )
                    occupants = bhava[2] if len(bhava) > 2 else []
                else:
                    total = float(bhava)
                    rasi_idx = int(total // 30)
                    occupants = []
                long_in_rasi = total % 30
                result["bhavas"].append(
                    {
                        "house": i + 1,
                        "madhya_rasi": rasi_id_to_name(rasi_idx),
                        "madhya_rasi_index": rasi_idx,
                        "madhya_longitude": round(long_in_rasi, 4),
                        "occupants": [str(occupant) for occupant in occupants],
                    }
                )
    except Exception as e:
        result["error"] = error_payload(e)

    return result
