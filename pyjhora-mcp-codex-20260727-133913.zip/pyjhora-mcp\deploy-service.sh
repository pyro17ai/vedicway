#!/usr/bin/env bash
set -euo pipefail

APP_NAME="pyjhora-mcp"
APP_USER="pyjhora"
APP_GROUP="pyjhora"
APP_DIR="/opt/pyjhora-mcp"
SERVICE_NAME="${APP_NAME}.service"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}"
CADDY_MAIN_FILE="/etc/caddy/Caddyfile"
CADDY_SNIPPET_DIR="/etc/caddy/Caddyfile.d"
CADDY_SNIPPET_FILE="${CADDY_SNIPPET_DIR}/${APP_NAME}.caddy"
ENV_FILE="${APP_DIR}/.env"
DOMAIN="${DOMAIN:-pyjhora-mcp.lairfrost.dev}"
APP_PORT="${APP_PORT:-8000}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

usage() {
    cat <<EOF
Usage: sudo bash ./deploy-service.sh <command>

Commands:
  install      Install/upgrade app, systemd service, and Caddy reverse proxy
  uninstall    Remove systemd service, Caddy config, app files, and app user
  reinstall    Run uninstall followed by install
  start        Start the app service and Caddy reverse proxy
  stop         Stop the app service and Caddy reverse proxy
  restart      Restart the app service and reload Caddy
  status       Show service and Caddy status
  logs         Tail service logs

Environment variables:
  DOMAIN       Domain name for Caddy reverse proxy (default: ${DOMAIN})
  APP_PORT     Internal app port (default: ${APP_PORT})

Env file:
  ${ENV_FILE}
  Add API_KEY there to enable Bearer token authentication.
EOF
}

require_root() {
    if [[ "${EUID}" -ne 0 ]]; then
        echo "This script must be run as root (use sudo)."
        exit 1
    fi
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

run_as_app_user() {
    if command_exists runuser; then
        runuser -u "${APP_USER}" -- "$@"
    else
        su -s /bin/bash -c "$(printf '%q ' "$@")" "${APP_USER}"
    fi
}

install_system_packages() {
    if ! command_exists apt-get; then
        echo "This script currently supports Debian/Ubuntu systems (apt-get required)."
        exit 1
    fi

    export DEBIAN_FRONTEND=noninteractive

    apt-get update

    # Install gnupg first (needed for Caddy repo key import)
    apt-get install -y gnupg

    # Try to install keyring packages — non-fatal on Debian 13/Trixie
    apt-get install -y debian-keyring debian-archive-keyring || true

    apt-get install -y \
        ca-certificates \
        curl \
        git \
        lsb-release \
        apt-transport-https \
        python3 \
        python3-venv \
        python3-pip \
        build-essential \
        swig \
        rsync

    if ! command_exists caddy; then
        mkdir -p /etc/apt/keyrings /usr/share/keyrings
        # Remove any previously broken sources entry
        rm -f /etc/apt/sources.list.d/caddy-stable.list
        # Write GPG key to both locations for compatibility
        curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /etc/apt/keyrings/caddy-stable-archive-keyring.gpg
        cp /etc/apt/keyrings/caddy-stable-archive-keyring.gpg /usr/share/keyrings/caddy-stable-archive-keyring.gpg
        # Use signed-by to avoid ambiguity
        echo "deb [signed-by=/usr/share/keyrings/caddy-stable-archive-keyring.gpg] https://dl.cloudsmith.io/public/caddy/stable/deb/debian any-version main" > /etc/apt/sources.list.d/caddy-stable.list
        apt-get update
        apt-get install -y caddy
    fi
}

ensure_app_user() {
    if ! getent group "${APP_GROUP}" >/dev/null 2>&1; then
        groupadd --system "${APP_GROUP}"
    fi

    if ! id -u "${APP_USER}" >/dev/null 2>&1; then
        useradd --system --gid "${APP_GROUP}" --create-home --home-dir /var/lib/${APP_NAME} --shell /usr/sbin/nologin "${APP_USER}"
    fi
}

sync_app_source() {
    mkdir -p "${APP_DIR}"
    rsync -a --delete \
        --exclude '.git' \
        --exclude '.venv' \
        --exclude '__pycache__' \
        --exclude '.pytest_cache' \
        "${SCRIPT_DIR}/" "${APP_DIR}/"
    chown -R "${APP_USER}:${APP_GROUP}" "${APP_DIR}"
}

setup_python_env() {
    if [[ ! -d "${APP_DIR}/.venv" ]]; then
        run_as_app_user python3 -m venv "${APP_DIR}/.venv"
    fi

    run_as_app_user "${APP_DIR}/.venv/bin/pip" install --upgrade pip setuptools wheel
    run_as_app_user "${APP_DIR}/.venv/bin/pip" install -r "${APP_DIR}/requirements.txt"
    run_as_app_user "${APP_DIR}/.venv/bin/pip" install -e "${APP_DIR}"
}

install_ephemeris_data() {
    local ephe_source_dir="${APP_DIR}/ephe"
    local tmp_ephe_dir=""

    if [[ ! -d "${ephe_source_dir}" ]] || [[ -z "$(find "${ephe_source_dir}" -maxdepth 1 -type f -print -quit)" ]]; then
        tmp_ephe_dir="$(mktemp -d)"
        bash "${APP_DIR}/setup-ephe.sh" "${tmp_ephe_dir}"
        ephe_source_dir="${tmp_ephe_dir}"
    fi

    local jhora_ephe_dir
    jhora_ephe_dir="$("${APP_DIR}/.venv/bin/python" -c 'import os, jhora; print(os.path.join(os.path.dirname(jhora.__file__), "data", "ephe"))')"
    mkdir -p "${jhora_ephe_dir}"
    cp -f "${ephe_source_dir}/"* "${jhora_ephe_dir}/"

    if [[ -n "${tmp_ephe_dir}" ]]; then
        rm -rf "${tmp_ephe_dir}"
    fi
}

write_env_file() {
    if [[ ! -f "${ENV_FILE}" ]]; then
        cat > "${ENV_FILE}" <<EOF
# Environment for ${APP_NAME}
# Set this to require Authorization: Bearer <token>
API_KEY=change_this_to_a_long_random_secret

# Optional: override internal app port used by service
# PORT=${APP_PORT}
EOF
        chmod 600 "${ENV_FILE}"
        chown "${APP_USER}:${APP_GROUP}" "${ENV_FILE}"
    fi
}

write_systemd_service() {
    cat > "${SERVICE_FILE}" <<EOF
[Unit]
Description=PyJHora MCP Server
After=network.target

[Service]
Type=simple
User=${APP_USER}
Group=${APP_GROUP}
WorkingDirectory=${APP_DIR}
Environment=PORT=${APP_PORT}
EnvironmentFile=-${ENV_FILE}
ExecStart=${APP_DIR}/.venv/bin/python -m pyjhora_mcp.server
Restart=always
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=${APP_DIR}

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable --now "${SERVICE_NAME}"
}

write_caddy_config() {
    mkdir -p "${CADDY_SNIPPET_DIR}"

    cat > "${CADDY_SNIPPET_FILE}" <<EOF
${DOMAIN} {
    encode zstd gzip
    reverse_proxy 127.0.0.1:${APP_PORT}
}
EOF

    if [[ ! -f "${CADDY_MAIN_FILE}" ]]; then
        echo "${CADDY_SNIPPET_DIR} not found and main Caddyfile missing."
        exit 1
    fi

    if ! grep -q "import ${CADDY_SNIPPET_DIR}/\*\.caddy" "${CADDY_MAIN_FILE}"; then
        cp "${CADDY_MAIN_FILE}" "${CADDY_MAIN_FILE}.bak.$(date +%s)"
        {
            echo ""
            echo "import ${CADDY_SNIPPET_DIR}/*.caddy"
        } >> "${CADDY_MAIN_FILE}"
    fi

    caddy validate --config "${CADDY_MAIN_FILE}"
    systemctl enable --now caddy
    systemctl reload caddy
}

install_all() {
    install_system_packages
    ensure_app_user
    sync_app_source
    setup_python_env
    install_ephemeris_data
    write_env_file
    write_systemd_service
    write_caddy_config

    echo ""
    echo "Installation complete."
    echo "Service:   systemctl status ${SERVICE_NAME}"
    echo "Caddy:     systemctl status caddy"
    echo "Env file:  ${ENV_FILE}"
    echo "Health:    curl -i https://${DOMAIN}/"
}

uninstall_all() {
    if systemctl list-unit-files | grep -q "^${SERVICE_NAME}"; then
        systemctl disable --now "${SERVICE_NAME}" || true
    fi

    rm -f "${SERVICE_FILE}"
    systemctl daemon-reload

    rm -f "${CADDY_SNIPPET_FILE}"
    if command_exists caddy && [[ -f "${CADDY_MAIN_FILE}" ]]; then
        caddy validate --config "${CADDY_MAIN_FILE}" || true
        systemctl reload caddy || true
    fi

    rm -rf "${APP_DIR}"

    if id -u "${APP_USER}" >/dev/null 2>&1; then
        userdel "${APP_USER}" || true
    fi

    echo "Uninstall complete."
    if [[ "${PURGE_ENV:-0}" != "1" ]]; then
        echo "Kept env file at ${ENV_FILE} (set PURGE_ENV=1 to remove on uninstall)."
    fi
}

start_all() {
    systemctl start "${SERVICE_NAME}" || true
    systemctl start caddy || true
    echo "Service started."
}

stop_all() {
    systemctl stop caddy || true
    systemctl stop "${SERVICE_NAME}" || true
    echo "Service stopped."
}

restart_all() {
    systemctl restart "${SERVICE_NAME}" || true
    if command_exists caddy; then
        systemctl reload caddy || systemctl restart caddy || true
    fi
    echo "Service restarted."
}

status_all() {
    echo "=== ${SERVICE_NAME} ==="
    systemctl status "${SERVICE_NAME}" --no-pager || true
    echo ""
    echo "=== Caddy ==="
    systemctl status caddy --no-pager || true
}

logs() {
    journalctl -u "${SERVICE_NAME}" -f
}

main() {
    local cmd="${1:-}"

    case "${cmd}" in
        install)
            require_root
            install_all
            ;;
        uninstall)
            require_root
            uninstall_all
            ;;
        reinstall)
            require_root
            uninstall_all
            install_all
            ;;
        start)
            require_root
            start_all
            ;;
        stop)
            require_root
            stop_all
            ;;
        restart)
            require_root
            restart_all
            ;;
        status)
            status_all
            ;;
        logs)
            logs
            ;;
        *)
            usage
            exit 1
            ;;
    esac
}

main "$@"
