# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is an MCP (Model Context Protocol) server that wraps PyJHora, a Vedic Astrology Python library. It exposes 22 astrological calculation tools via FastMCP framework.

**Critical Requirement**: Ephemeris data files (.se1) must be manually installed from PyJHora GitHub (`src/jhora/data/ephe/`) into the `jhora/data/ephe/` package directory. Without these, all calculations fail.

## Common Commands

```bash
# Setup
uv venv
uv pip install -e ".[dev]"

# Run MCP server
fastmcp run src/pyjhora_mcp/server.py                    # stdio (Claude Desktop)
fastmcp run src/pyjhora_mcp/server.py --transport http --port 8000  # HTTP debug

# Run tests (requires ephemeris files)
uv run pytest tests/ -v
uv run pytest tests/test_panchanga.py -v                           # single file
uv run pytest tests/test_panchanga.py::test_name -v              # single test

# Coverage
uv run pytest tests/ --cov=src/pyjhora_mcp --cov-report=term-missing

# Lint & type check
uv run ruff format src/ tests/
uv run ruff check src/ tests/
uv run mypy src/pyjhora_mcp/

# Docker
docker build -t pyjhora-mcp:latest .
docker-compose up
```

## Architecture

The server uses a modular architecture:

```
src/pyjhora_mcp/
├── server.py          # FastMCP entry point, mounts 6 tool routers
├── models/schemas.py  # Pydantic input/output models
├── utils/converters.py # Date/place conversion, ID-to-name mappings
└── tools/
    ├── panchanga.py   # 6 tools: panchanga, sunrise/sunset, rahu_kala, muhurtha, planet_positions, festivals
    ├── horoscope.py   # 5 tools: rasi_chart, divisional_chart, special_lagnas, ashtakavarga, bhava_chart
    ├── dasha.py       # 4 tools: vimsottari, yogini, ashtottari, narayana
    ├── compatibility.py # 1 tool: marriage compatibility (Ashta Koota + Dasa Porutham)
    ├── yoga.py        # 3 tools: yogas (284+), doshas (8), raja_yogas
    └── strength.py    # 3 tools: shadbala, bhava_bala, vimsopaka_bala
```

Each tool module exports its own `FastMCP` instance (`mcp`), which gets mounted in `server.py`. The `converters.py` module provides bidirectional conversion between Pydantic models and PyJHora internal types (Place namedtuple, Julian Day, etc.).

### Data Flow

1. MCP client sends Pydantic-validated input (via FastMCP)
2. Tool function calls `converters.py` helpers to transform to PyJHora types
3. Sets ayanamsa mode, calls PyJHora library
4. Converts results back to dict/JSON for MCP response
