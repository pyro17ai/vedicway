"""Marriage compatibility MCP tools.

Wraps: jhora.horoscope.match.compatibility
"""

from __future__ import annotations

from typing import Any

from fastmcp import FastMCP

from pyjhora_mcp.models.schemas import CompatibilityInput, CompatibilityResult
from pyjhora_mcp.utils.converters import (
    error_payload,
    nakshatra_id_to_name,
    rasi_id_to_name,
    set_ayanamsa,
    to_julian_day,
    to_place,
)

mcp = FastMCP(name="Compatibility Tools")


def _date_string(date_time: Any) -> str:
    return f"{date_time.year}-{date_time.month:02d}-{date_time.day:02d}"


# ---------------------------------------------------------------------------
# get_compatibility
# ---------------------------------------------------------------------------


@mcp.tool
def get_compatibility(input_data: CompatibilityInput) -> CompatibilityResult:
    """Calculate marriage compatibility between two individuals using Vedic astrology.

    Computes both **Ashta Koota** (North Indian, 8-point system, max 36 points)
    and **South Indian Dasa Porutham** (10-point Tamil system) methods.

    The 8 Ashta Koota factors:
    1. Varna (1 pt) — Social/spiritual compatibility
    2. Vashya (2 pts) — Magnetic attraction
    3. Tara (3 pts) — Birth star compatibility
    4. Yoni (4 pts) — Biological/sexual compatibility
    5. Graha Maitri (5 pts) — Friendship between sign lords
    6. Gana (6 pts) — Nature/temperament
    7. Bhakoot (7 pts) — Emotional/financial compatibility
    8. Nadi (8 pts) — Health and genetic compatibility

    Score interpretation:
    - < 18: Not recommended
    - 18–24: Average compatibility
    - 24–32: Good compatibility
    - > 32: Excellent compatibility

    Args:
        input_data: Birth details for both boy and girl.

    Returns:
        Dictionary with total score, individual factor scores,
        and recommendations.
    """
    from jhora.horoscope.match import compatibility

    # Use boy's ayanamsa as the default for consistency
    set_ayanamsa(input_data.boy_birth.ayanamsa.value)

    boy_jd = to_julian_day(input_data.boy_birth.date_time)
    boy_place = to_place(input_data.boy_birth.place)
    girl_jd = to_julian_day(input_data.girl_birth.date_time)
    girl_place = to_place(input_data.girl_birth.place)

    result: dict[str, Any] = {
        "method": "Ashta Koota + South Indian (Dasa Porutham)",
        "ayanamsa": input_data.boy_birth.ayanamsa.value,
        "boy": {
            "date": _date_string(input_data.boy_birth.date_time),
            "place": input_data.boy_birth.place.name,
        },
        "girl": {
            "date": _date_string(input_data.girl_birth.date_time),
            "place": input_data.girl_birth.place.name,
        },
    }

    try:
        from jhora.panchanga import drik

        boy_nak = drik.nakshatra(boy_jd, boy_place)
        girl_nak = drik.nakshatra(girl_jd, girl_place)
        boy_nid, boy_pada = int(boy_nak[0]), int(boy_nak[1])
        girl_nid, girl_pada = int(girl_nak[0]), int(girl_nak[1])

        matcher = compatibility.Ashtakoota(boy_nid, boy_pada, girl_nid, girl_pada)
        score = matcher.compatibility_score()
        labels = [
            "varna",
            "vasiya",
            "gana",
            "tara",
            "yoni",
            "graha_maitri",
            "bhakoot",
            "nadi",
        ]

        result["total_score"] = float(score[8])
        result["ashta_koota"] = {label: score[index] for index, label in enumerate(labels)}
        result["south_indian_porutham"] = {
            "mahendra": bool(score[9]),
            "vedha": bool(score[10]),
            "rajju": bool(score[11]),
            "sthree_dheerga": bool(score[12]),
        }
        result["boy"]["nakshatra"] = nakshatra_id_to_name(boy_nid)
        result["boy"]["nakshatra_index"] = boy_nid
        result["boy"]["pada"] = boy_pada
        result["girl"]["nakshatra"] = nakshatra_id_to_name(girl_nid)
        result["girl"]["nakshatra_index"] = girl_nid
        result["girl"]["pada"] = girl_pada

    except Exception as e:
        result["error"] = error_payload(e)

    # Also compute basic nakshatra compatibility manually as fallback
    try:
        from jhora.panchanga import drik

        # Moon rasi for both
        from jhora.panchanga.drik import sidereal_longitude

        boy_moon_long = sidereal_longitude(boy_jd, 1)  # 1 = Moon
        girl_moon_long = sidereal_longitude(girl_jd, 1)
        if boy_moon_long is not None:
            result["boy"]["moon_rasi"] = rasi_id_to_name(int(float(boy_moon_long) // 30))
        if girl_moon_long is not None:
            result["girl"]["moon_rasi"] = rasi_id_to_name(int(float(girl_moon_long) // 30))

    except Exception:
        pass  # Supplementary info, non-critical

    return result
