"""Dasha (planetary period) MCP tools.

Wraps: jhora.horoscope.chart.dhasa.graha and raasi
"""

from __future__ import annotations

from typing import Any

from fastmcp import FastMCP

from pyjhora_mcp.models.schemas import BirthDataInput, DashaResult
from pyjhora_mcp.utils.converters import (
    error_payload,
    planet_id_to_name,
    rasi_id_to_name,
    set_ayanamsa,
    to_julian_day,
    to_place,
)

mcp = FastMCP(name="Dasha Tools")

DashaPeriod = dict[str, Any]


def _birth_date_and_time(date_time: Any) -> tuple[Any, tuple[float, int, int]]:
    from jhora.panchanga import drik

    date = drik.Date(date_time.year, date_time.month, date_time.day)
    fractional_hour = date_time.hour + date_time.minute / 60.0 + date_time.second / 3600.0
    return date, (fractional_hour, 0, 0)


def _rasi_lord_to_name(lord: Any) -> str:
    value = str(lord).replace("Planet-", "").replace("Rahu", "7").replace("Ketu", "8")
    try:
        rasi_idx = int(value)
    except ValueError:
        return str(lord)
    if 0 <= rasi_idx <= 11:
        return rasi_id_to_name(rasi_idx)
    return str(lord)


def _parse_flat_dasha_list(flat_list: list, depth: int) -> list[DashaPeriod]:
    """Parse PyJHora 4.7.0 flat list dhasa arrays (with strings) into structured dicts."""
    grouped: dict[str, DashaPeriod] = {}
    periods: list[DashaPeriod] = []

    if depth <= 1:
        for row in flat_list:
            if len(row) < 2:
                continue
            # row format: [lord, start_str, (optional duration)]
            lord = planet_id_to_name(row[0]) if isinstance(row[0], int) else str(row[0])
            start = str(row[1])
            periods.append({"lord": lord, "start": start, "end": "N/A"})

        for i in range(len(periods) - 1):
            periods[i]["end"] = periods[i + 1]["start"]

    else:
        for row in flat_list:
            if len(row) < 3:
                continue
            # row format: [maha_lord, antara_lord, start_str, (optional duration)]
            m_lord = planet_id_to_name(row[0]) if isinstance(row[0], int) else str(row[0])
            a_lord = planet_id_to_name(row[1]) if isinstance(row[1], int) else str(row[1])
            start = str(row[2])

            if m_lord not in grouped:
                grouped[m_lord] = {
                    "lord": m_lord,
                    "start": start,
                    "end": "N/A",
                    "sub_periods": [],
                }
                periods.append(grouped[m_lord])

            grouped[m_lord]["sub_periods"].append({"lord": a_lord, "start": start, "end": "N/A"})

        for p_idx, p in enumerate(periods):
            subs = p["sub_periods"]
            for s_idx in range(len(subs) - 1):
                subs[s_idx]["end"] = subs[s_idx + 1]["start"]

            if p_idx < len(periods) - 1:
                p["end"] = periods[p_idx + 1]["start"]
                if subs:
                    subs[-1]["end"] = periods[p_idx + 1]["start"]
            else:
                p["end"] = "N/A"
                if subs:
                    subs[-1]["end"] = "N/A"

    return periods


# ---------------------------------------------------------------------------
# get_vimsottari_dasha
# ---------------------------------------------------------------------------


@mcp.tool
def get_vimsottari_dasha(
    birth_data: BirthDataInput,
    include_antara: bool = True,
    include_pratyantara: bool = False,
) -> DashaResult:
    """Calculate Vimsottari Dasha periods for a given birth chart.

    Vimsottari is the most widely used dasha system in Vedic astrology,
    spanning a total cycle of 120 years across 9 planetary lords.

    Args:
        birth_data: Birth location, date, time, and ayanamsa.
        include_antara: Include Antara (sub-periods) within each Maha Dasha. Default True.
        include_pratyantara: Include Pratyantara (sub-sub-periods). Default False.

    Returns:
        Dictionary with list of Maha Dasha periods, each with start/end dates
        and optionally Antara/Pratyantara sub-periods.
    """
    from jhora.horoscope.dhasa.graha import vimsottari

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {
        "dasha_system": "Vimsottari",
        "total_years": 120,
        "ayanamsa": birth_data.ayanamsa.value,
        "maha_dashas": [],
    }

    try:
        if include_pratyantara:
            depth = 3
        elif include_antara:
            depth = 2
        else:
            depth = 1

        _, dhasa_list = vimsottari.get_vimsottari_dhasa_bhukthi(
            jd, place, dhasa_level_index=depth
        )
        result["maha_dashas"] = _parse_flat_dasha_list(dhasa_list, depth)

    except Exception as e:
        result["error"] = error_payload(e)

    return result


# ---------------------------------------------------------------------------
# get_yogini_dasha
# ---------------------------------------------------------------------------


@mcp.tool
def get_yogini_dasha(
    birth_data: BirthDataInput,
    include_antara: bool = True,
) -> DashaResult:
    """Calculate Yogini Dasha periods for a given birth chart.

    Yogini dasha spans a total of 36 years across 8 Yogini lords.

    Args:
        birth_data: Birth location, date, time, and ayanamsa.
        include_antara: Include Antara sub-periods. Default True.

    Returns:
        Dictionary with Yogini Dasha periods.
    """
    from jhora.horoscope.dhasa.graha import yogini

    set_ayanamsa(birth_data.ayanamsa.value)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {
        "dasha_system": "Yogini",
        "total_years": 36,
        "maha_dashas": [],
    }

    try:
        dob, tob = _birth_date_and_time(birth_data.date_time)
        depth = 2 if include_antara else 1
        dhasa_list = yogini.get_dhasa_bhukthi(dob, tob, place, dhasa_level_index=depth)
        result["maha_dashas"] = _parse_flat_dasha_list(dhasa_list, depth)
    except Exception as e:
        result["error"] = error_payload(e)

    return result


# ---------------------------------------------------------------------------
# get_ashtottari_dasha
# ---------------------------------------------------------------------------


@mcp.tool
def get_ashtottari_dasha(
    birth_data: BirthDataInput,
    include_antara: bool = True,
) -> DashaResult:
    """Calculate Ashtottari Dasha periods for a given birth chart.

    Ashtottari spans 108 years and is used when Rahu is in a Kendra or Trikona
    from the Lagna or Moon (conditional dasha).

    Args:
        birth_data: Birth location, date, time, and ayanamsa.
        include_antara: Include Antara sub-periods. Default True.

    Returns:
        Dictionary indicating applicability and dasha periods if applicable.
    """
    from jhora.horoscope.dhasa.graha import ashtottari

    set_ayanamsa(birth_data.ayanamsa.value)
    jd = to_julian_day(birth_data.date_time)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {
        "dasha_system": "Ashtottari",
        "total_years": 108,
        "maha_dashas": [],
    }

    try:
        depth = 2 if include_antara else 1
        dhasa_list = ashtottari.get_ashtottari_dhasa_bhukthi(
            jd,
            place,
            dhasa_level_index=depth,
        )
        result["maha_dashas"] = _parse_flat_dasha_list(dhasa_list, depth)
    except Exception as e:
        result["error"] = error_payload(e)

    return result


# ---------------------------------------------------------------------------
# get_narayana_dasha
# ---------------------------------------------------------------------------


@mcp.tool
def get_narayana_dasha(
    birth_data: BirthDataInput,
    divisional_chart: int = 1,
    include_antara: bool = True,
) -> DashaResult:
    """Calculate Narayana Dasha (Rasi dasha) periods for a given birth chart.

    Narayana Dasha is a sign-based (Rasi) dasha system widely used for
    timing of events related to houses and their lords.

    Args:
        birth_data: Birth location, date, time, and ayanamsa.
        divisional_chart: Varga chart to use (1=Rasi, 9=Navamsa). Default 1.
        include_antara: Include Antara sub-periods. Default True.

    Returns:
        Dictionary with Narayana Dasha periods (lords are Rasi names).
    """
    from jhora.horoscope.dhasa.raasi import narayana

    set_ayanamsa(birth_data.ayanamsa.value)
    place = to_place(birth_data.place)

    result: dict[str, Any] = {
        "dasha_system": "Narayana (Rasi)",
        "divisional_chart": f"D{divisional_chart}",
        "maha_dashas": [],
    }

    try:
        dob, tob = _birth_date_and_time(birth_data.date_time)
        depth = 2 if include_antara else 1
        dhasa_list = narayana.narayana_dhasa_for_divisional_chart(
            dob,
            tob,
            place,
            divisional_chart_factor=divisional_chart,
            dhasa_level_index=depth,
        )

        # Narayana dasha lords are rasi indices, convert
        parsed = _parse_flat_dasha_list(dhasa_list, depth)

        # Replace numeric lords with rasi names where possible
        for entry in parsed:
            entry["lord"] = _rasi_lord_to_name(entry["lord"])
            for sub in entry.get("sub_periods", []):
                sub["lord"] = _rasi_lord_to_name(sub["lord"])

        result["maha_dashas"] = parsed

    except Exception as e:
        result["error"] = error_payload(e)

    return result
