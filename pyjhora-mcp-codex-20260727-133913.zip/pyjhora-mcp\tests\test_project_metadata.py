"""Project metadata checks for reproducible installs."""

from __future__ import annotations

import tomllib
from pathlib import Path


def test_pyproject_declares_runtime_dependencies_used_by_pyjhora() -> None:
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
    project = pyproject["project"]
    dependencies = project["dependencies"]

    assert project["requires-python"] == ">=3.11,<3.12"
    assert "PyJHora==4.7.0" in dependencies
    assert "pyswisseph==2.10.3.2" in dependencies
