"""Pydantic input/output models shared across all MCP tools."""

from __future__ import annotations

from enum import Enum, StrEnum
from typing import Any, NotRequired

from pydantic import BaseModel, Field
from typing_extensions import TypedDict

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class AyanamsaMode(StrEnum):
    """Supported ayanamsa modes in PyJHora."""

    LAHIRI = "LAHIRI"
    TRUE_PUSHYA = "TRUE_PUSHYA"
    KP = "KP"
    RAMAN = "RAMAN"
    YUKTESHWAR = "YUKTESHWAR"
    JN_BHASIN = "JN_BHASIN"
    BABYL_KUGLER1 = "BABYL_KUGLER1"
    BABYL_KUGLER2 = "BABYL_KUGLER2"
    BABYL_KUGLER3 = "BABYL_KUGLER3"


class DivisionalChart(int, Enum):
    """Common divisional chart numbers."""

    D1 = 1  # Rasi
    D2 = 2  # Hora
    D3 = 3  # Drekkana
    D4 = 4  # Chaturthamsa
    D7 = 7  # Saptamsa
    D9 = 9  # Navamsa
    D10 = 10  # Dasamsa
    D12 = 12  # Dwadasamsa
    D16 = 16  # Shodasamsa
    D20 = 20  # Vimsamsa
    D24 = 24  # Chaturvimsamsa / Siddhamsa
    D27 = 27  # Nakshatramsa / Bhamsa
    D30 = 30  # Trimsamsa
    D40 = 40  # Khavedamsa
    D45 = 45  # Akshavedamsa
    D60 = 60  # Shashtyamsa


# ---------------------------------------------------------------------------
# Input models
# ---------------------------------------------------------------------------


class PlaceInput(BaseModel):
    """Geographic location for astrological calculation."""

    name: str = Field(
        description="Place name with country code, e.g. 'Chennai,IN' or 'New York,US'"
    )
    latitude: float = Field(
        description="Latitude in decimal degrees. North is positive, South is negative.",
        ge=-90.0,
        le=90.0,
    )
    longitude: float = Field(
        description="Longitude in decimal degrees. East is positive, West is negative.",
        ge=-180.0,
        le=180.0,
    )
    timezone: float = Field(
        description="UTC offset in hours, e.g. +5.5 for IST, -5.0 for EST",
        ge=-14.0,
        le=14.0,
    )


class DateTimeInput(BaseModel):
    """Date and time for astrological calculations."""

    year: int = Field(description="Year (Gregorian). Negative values are B.C.")
    month: int = Field(description="Month (1–12)", ge=1, le=12)
    day: int = Field(description="Day of month (1–31)", ge=1, le=31)
    hour: int = Field(default=0, description="Hour (0–23)", ge=0, le=23)
    minute: int = Field(default=0, description="Minute (0–59)", ge=0, le=59)
    second: int = Field(default=0, description="Second (0–59)", ge=0, le=59)


class BirthDataInput(BaseModel):
    """Combined birth data: place + date/time."""

    place: PlaceInput = Field(description="Birth location")
    date_time: DateTimeInput = Field(description="Birth date and time (local time)")
    ayanamsa: AyanamsaMode = Field(
        default=AyanamsaMode.LAHIRI,
        description="Ayanamsa mode to use for calculations. Default is LAHIRI.",
    )


class CompatibilityInput(BaseModel):
    """Input for marriage compatibility calculation."""

    boy_birth: BirthDataInput = Field(description="Boy's birth details")
    girl_birth: BirthDataInput = Field(description="Girl's birth details")


# ---------------------------------------------------------------------------
# Output models
# ---------------------------------------------------------------------------


class PanchangaOutput(BaseModel):
    """Panchanga (daily almanac) output."""

    tithi: dict[str, Any] = Field(description="Tithi (lunar day) with index and end time")
    nakshatra: dict[str, Any] = Field(
        description="Nakshatra (lunar mansion) with index and end time"
    )
    yoga: dict[str, Any] = Field(description="Yoga with index and end time")
    karana: dict[str, Any] = Field(description="Karana with index and end time")
    vaara: str = Field(description="Day of week (Vaara)")
    masa: str = Field(description="Lunar month name")
    samvatsara: str = Field(description="Vedic year name")


class PlanetInfo(BaseModel):
    """Information about a single planet's position."""

    planet: str = Field(description="Planet name")
    rasi: str = Field(description="Sign/Rasi name (Aries, Taurus, …)")
    rasi_index: int = Field(description="Rasi index (0=Aries, 1=Taurus, …, 11=Pisces)")
    longitude: float = Field(description="Longitude within rasi in decimal degrees (0–30)")
    is_retrograde: bool = Field(default=False, description="Whether planet is in retrograde")
    nakshatra: str = Field(default="", description="Nakshatra of planet")


class ChartOutput(BaseModel):
    """Astrological chart output."""

    ascendant: PlanetInfo = Field(description="Lagna / Ascendant")
    planets: list[PlanetInfo] = Field(description="List of planet positions")
    chart_notes: str = Field(default="", description="Additional notes about the chart")


class ErrorValue(TypedDict):
    """Machine-readable error shared by all tool responses."""

    code: str
    type: str
    message: str
    recoverable: bool


class ErrorResult(TypedDict, total=False):
    """A partial field or response containing a calculation error."""

    error: ErrorValue


class PositionResult(TypedDict, total=False):
    """Position fields shared by chart and planet-position tools."""

    planet: NotRequired[str]
    planet_index: NotRequired[int]
    rasi: NotRequired[str]
    rasi_index: NotRequired[int]
    longitude_in_rasi: NotRequired[float]
    total_longitude: NotRequired[float]
    nakshatra: NotRequired[str]
    nakshatra_index: NotRequired[int]
    pada: NotRequired[int]


class AscendantResult(PositionResult, total=False):
    """Ascendant position fields."""


class TithiResult(TypedDict, total=False):
    index: int
    name: str
    paksha: str
    end_time: str


class NakshatraResult(TypedDict, total=False):
    index: int
    name: str
    end_time: str
    pada: int


class YogaResult(TypedDict, total=False):
    index: int
    name: str
    end_time: str


class KaranaResult(TypedDict, total=False):
    index: int
    name: str


class PeriodResult(TypedDict, total=False):
    start: str
    end: str
    error: NotRequired[ErrorValue]


class PanchangaResult(TypedDict, total=False):
    tithi: TithiResult | ErrorResult
    nakshatra: NakshatraResult | ErrorResult
    yoga: YogaResult | ErrorResult
    karana: KaranaResult | ErrorResult
    vaara: str | ErrorResult
    masa: str | ErrorResult
    samvatsara: str | ErrorResult
    ritu: int | ErrorResult


class SunriseSunsetResult(TypedDict, total=False):
    sunrise: str | ErrorResult
    sunset: str | ErrorResult
    moonrise: str | ErrorResult
    moonset: str | ErrorResult
    midday: str | ErrorResult
    midnight: str | ErrorResult


class RahuKalaResult(TypedDict, total=False):
    rahu_kalam: PeriodResult | ErrorResult
    yamaganda_kalam: PeriodResult | ErrorResult
    gulika_kalam: PeriodResult | ErrorResult


class MuhurthaResult(TypedDict, total=False):
    abhijit_muhurtha: PeriodResult | ErrorResult
    durmuhurtham: list[PeriodResult] | ErrorResult
    brahma_muhurtha: PeriodResult | ErrorResult
    godhuli_muhurtha: PeriodResult | ErrorResult
    vijaya_muhurtha: PeriodResult | ErrorResult
    nishita_muhurtha: PeriodResult | ErrorResult


class PlanetPositionsResult(TypedDict, total=False):
    planets: dict[str, PositionResult | ErrorResult]
    ascendant: AscendantResult | ErrorResult
    planets_error: ErrorValue


class FestivalsResult(TypedDict, total=False):
    date: str
    festivals: list[dict[str, Any]]
    error: ErrorValue


class RasiChartResult(TypedDict, total=False):
    chart_type: str
    ayanamsa: str
    ascendant: AscendantResult | ErrorResult
    planets: list[PositionResult]
    planets_error: ErrorValue


class DivisionalChartResult(RasiChartResult, total=False):
    divisor: int


class SpecialLagnasResult(TypedDict, total=False):
    hora_lagna: PositionResult | ErrorResult
    ghati_lagna: PositionResult | ErrorResult
    vighati_lagna: PositionResult | ErrorResult
    pranapada_lagna: PositionResult | ErrorResult
    indu_lagna: PositionResult | ErrorResult
    sree_lagna: PositionResult | ErrorResult


class AshtakavargaResult(TypedDict, total=False):
    bhinnashtakavarga: dict[str, dict[str, int | float]]
    samudaya_ashtakavarga: dict[str, int | float]
    bhinnashtakavarga_error: ErrorValue
    samudaya_ashtakavarga_error: ErrorValue
    error: ErrorValue


class BhavaResult(TypedDict, total=False):
    house: int
    madhya_rasi: str
    madhya_rasi_index: int
    madhya_longitude: float
    occupants: list[str]


class BhavaChartResult(TypedDict, total=False):
    method: int
    bhavas: list[BhavaResult]
    error: ErrorValue


class DashaPeriodResult(TypedDict, total=False):
    lord: str
    start: str
    end: str
    sub_periods: list[DashaPeriodResult]


class DashaResult(TypedDict, total=False):
    dasha_system: str
    total_years: int
    ayanamsa: str
    divisional_chart: str
    maha_dashas: list[DashaPeriodResult]
    error: ErrorValue


class CompatibilityResult(TypedDict, total=False):
    method: str
    ayanamsa: str
    boy_birth: dict[str, Any]
    girl_birth: dict[str, Any]
    total_score: float
    ashta_koota: dict[str, Any]
    south_indian_porutham: dict[str, bool]
    boy_nakshatra: dict[str, Any]
    girl_nakshatra: dict[str, Any]
    boy_moon_rasi: str
    girl_moon_rasi: str
    error: ErrorValue


class YogasResult(TypedDict, total=False):
    yogas: list[dict[str, Any]]
    count: int
    total_checked: int
    error: ErrorValue


class DoshasResult(TypedDict, total=False):
    doshas: dict[str, dict[str, Any]]
    error: ErrorValue


class RajaYogasResult(TypedDict, total=False):
    raja_yogas: list[dict[str, Any]]
    count: int
    total_checked: int
    error: ErrorValue


class ShadbalaResult(TypedDict, total=False):
    shadbala: dict[str, dict[str, Any]]
    error: ErrorValue


class BhavaBalaResult(TypedDict, total=False):
    bhava_bala: dict[str, dict[str, Any]]
    error: ErrorValue


class VimsopakaBalaResult(TypedDict, total=False):
    vimsopaka_bala: dict[str, dict[str, Any]]
    error: ErrorValue
