from __future__ import annotations

import os

from fastmcp import FastMCP
from fastmcp.server.auth.providers.jwt import StaticTokenVerifier

from pyjhora_mcp.tools import compatibility, dasha, horoscope, panchanga, strength, yoga

# Authentication Setup
auth = None
api_key = os.environ.get("API_KEY")
if api_key:
    auth = StaticTokenVerifier(
        tokens={
            api_key: {
                "client_id": "default-user",
                "scopes": [],
            }
        }
    )

mcp = FastMCP(
    name="PyJHora Vedic Astrology Server",
    instructions="""This MCP server exposes Vedic (Jyotish) astrology calculations powered by the
PyJHora library (v4.7.0). It provides tools for:

- Panchanga: Tithi, Nakshatra, Yoga, Karana, Vaara, Sunrise/Sunset, Muhurtha,
  Rahu Kalam.
- Horoscope: Birth charts, divisional charts, special lagnas, Ashtakavarga,
  and Bhava charts.
- Dasha: Vimsottari, Yogini, Ashtottari, and Narayana dasha periods.
- Compatibility: Marriage matching using Ashta Koota and South Indian porutham.
- Yogas and doshas: planetary yogas, doshas, and Raja Yogas.
- Planetary strength: Shadbala, Bhava Bala, and Vimsopaka Bala.

All calculations use Swiss Ephemeris (pyswisseph) for precision.

Default Ayanamsa: LAHIRI unless specified otherwise per tool call.

Note: Ephemeris data files (.se1) must be present in jhora/data/ephe/ for
calculations to work.
""",
    auth=auth,
)

# Mount all tool routers
mcp.mount(panchanga.mcp)
mcp.mount(horoscope.mcp)
mcp.mount(dasha.mcp)
mcp.mount(compatibility.mcp)
mcp.mount(yoga.mcp)
mcp.mount(strength.mcp)


def main() -> None:
    """Entry point for the MCP server."""
    # Render and other clouds provide a PORT environment variable.
    port = int(os.environ.get("PORT", 8000))
    mcp.run(transport="http", host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()
